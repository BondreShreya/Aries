<!DOCTYPE html>
<html lang="en">

 <?php include('include/head.php'); ?>
 <style>
 
</style>
<script src="https://kit.fontawesome.com/a076d05399.js"></script>
<body>
    <!-- ##### Preloader ##### -->
    <!-- <div id="preloader">
        <i class="circle-preloader"></i>
    </div> -->

    <!-- ##### Header Area Start ##### -->
   <?php include('include/header.php'); ?>
    <!-- ##### Header Area End ##### -->

    <!-- ##### Hero Area Start ##### -->

    <section>
    
       


            <!-- Single Hero Slide -->

            <div class="single-hero-slide1 mt-4 bg2-img">
 
                <div class="container h-100">
                    <div class="row h-100 align-items-center">
                        <div class="col-12">
                            <div class="hero-slides-content">
                            <h3 class="heading pb-2">US Servers</h3>
                            <p class="text-justify mt-4">Leverage our US datacenter to power your online apps to meet the most demanding IO intensive and processor intensive workloads.<br>
                            Choose from a wide range of dedicated server hosting configurations customized to suit your business needs & budgets.<br>

                            Our promise of highest uptime, Superfast connectivity & lowest latency will ensure<br> that your applications are always on and so will be your business.</p>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Single Hero Slide -->

        
    </section>
    <!-- ##### Hero Area End ##### -->
    <section>
        <nav aria-label="breadcrumb">
          <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="index.php">Home</a></li>
            <li class="breadcrumb-item active" aria-current="page"><a href="colocation.php">Dedicated Server</a></li>
            <li class="breadcrumb-item">US Server</li>
          </ol>
        </nav>
    </section>
    
    <section>
        <div class="container">
            <div class="row">
                <div class="col-md-1">
                    
                </div>
                <div class="col-md-10">
                <!-- table -->
                    <table class="table table-bordered table-responsive">
                      <thead>
                        <tr>
                            <th></th>
                          <th>USS 1</th>
                          <th> USS 2</th>
                          <th class="border-0" style="background-color: #e8f6e8"> <strong>Best Value </strong><br>USS 3</th>
                          <th> USS 4</th>
                        </tr>
                      </thead>
                      <tbody>
                         <tr>
                           <th style="color: #6fc572">Processor </th>
                           <td>Dual Core Intel I3-2120</td>
                           <td>Quad Core Xeon E5-2609</td>
                           <td class="border-0" style="background-color: #e8f6e8">Hexa Core Xeon E5-2620</td>
                           <td>2 x HexaCore Xeon E5-2620</td>
                         </tr>
                        <tr>
                           <th style="color: #6fc572">Memory</th>
                           <td>4 GB RAM</td>
                           <td>8 GB RAM</td>
                           <td class="border-0" style="background-color: #e8f6e8; border: none;">16 GB RAM</td>
                           <td>32 GB RAM</td>
                         </tr>
                         <tr>
                           <th style="color: #6fc572">Disk space
                           </th>
                           <td>2 X 500 GB SATA (Raid 1)</td>
                           <td>2 X 500 GB SATA (Raid 1)</td>
                           <td class="border-0" style="background-color: #e8f6e8">2 X 500 GB SATA (Raid 1)</td>
                           <td>2 x 300 GB SAS (Raid 1)</td>
                         </tr>
                        <tr>
                           <th style="color: #6fc572">Bandwidth </th>
                           <td>500 GB Data Transfer</td>
                           <td>500 GB Data Transfer</td>
                           <td class="border-0" style="background-color: #e8f6e8">500 GB Data Transfer</td>
                           <td>500 GB Data Transfer</td>
                         </tr>
                        <tr>
                           <th style="color: #6fc572">IP addresses </th>
                           <td>1 IP's</td>
                           <td>1 IP's</td>
                           <td class="border-0" style="background-color: #e8f6e8">1 IP's</td>
                           <td>1 IP's</td>
                         </tr>
                         <tr>
                           <th style="color: #6fc572">Choice of OS </th>
                           <td>
                            <input type="radio" value="4110(Linux)" name="radio" checked="checked">
                            <img src="img\linux.png" title="Linux LOGO" align="absmiddle">
                            <input type="radio" value="4700(Windows)">
                            <img src="img\windows.png" title="Cloud OS" align="absmiddle"> </td>
                           <td>
                            <input type="radio" value="4110(Linux)" name="radio" checked="checked">
                            <img src="img\linux.png" title="Linux LOGO" align="absmiddle">
                            <input type="radio" value="4700(Windows)">
                            <img src="img\windows.png" title="Cloud OS" align="absmiddle">
                           </td>
                           <td class="border-0" style="background-color: #e8f6e8">
                            <input type="radio" value="4110(Linux)" name="radio" checked="checked">
                            <img src="img\linux.png" title="Linux LOGO" align="absmiddle">
                            <input type="radio" value="4700(Windows)">
                            <img src="img\windows.png" title="Cloud OS" align="absmiddle">
                           </td>
                           <td><input type="radio" value="4110(Linux)" name="radio" checked="checked">
                            <img src="img\linux.png" title="Linux LOGO" align="absmiddle">
                            <input type="radio" value="4700(Windows)">
                            <img src="img\windows.png" title="Cloud OS" align="absmiddle">
                           </td>
                         </tr>
                         <tr>
                       <td></td>
                       <td>
                        <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal">
                            Request a Proposal
                        </button>
                       </td>
                       <td>
                        <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal1">
                            Request a Proposal
                        </button>
                       </td>
                       <td class="border-0" style="background-color: #e8f6e8">
                        <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal2">
                            Request a Proposal
                        </button>
                       </td>
                       <td>
                        <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal3">
                            Request a Proposal
                        </button>
                       </td>
                     </tr>
                      </tbody>
                    </table>
                <!-- //table -->
                </div>
                <div class="col-md-1">
                    
                </div>
            </div>
        </div>
    </section>
    <!-- ##### ##### -->
    <div class="partner-area pt-5">
        <div class="container">
                 <div class="row">
                    <div class="col-md-9">
                        <h4 style="color: #021058">US SERVERS</h4>
                        <p>CtrlS US Data Center is a 57,000 square-foot facility located in the San Diego Spectrum area.</p>
                        <p>CTRLS was originally designed to support colocation for a large defense contractor. It is an SSAE 16 compliant,SOC 1, 2, and 3 audited data center that features:</p>
                        <ul style="padding-left:25px; line-height:1.5">
                            <li style="text-align:justify;">- 9.1 megawatts of SDG&amp;E utility-provided service coupled with the new state-of-the-art interactive distributed generation system providing seamless transition from utility service to stand-by emergency generator power without interruption</li>
                            <li style="text-align:justify;">-  Dual-source supported power distribution for all client hardware; single source feeds available as a client option</li>
                            <li style="text-align:justify;">-  Multiple path power distribution using state-of-the-art static switched power distribution units supported by multiple UPS systems</li>
                            <li style="text-align:justify;">-  Individual cabinets and secure caged access-controlled environments</li>
                            <li style="text-align:justify;">-  8 KW pre-configured rack designs and individual a la carte racks of up to 8 KW for client-configured environments</li>
                            <li style="text-align:justify;">-  Environmental systems that provide optimal environmental controls for IT hardware performance consistent with ASHRAE TC 9.9</li>
                            <li style="text-align:justify;">- Single inter-lock pre-action fire suppression system support throughout the facility</li>
                          </ul>
                        <div class="reasons">
                            <h4 style="color: #021058">6 REASONS YOU’LL LOVE OUR SERVERS</h4>
                            <div class="holder">
                                <div class="column">
                                    <div class="img">
                                        <img src="img/server/power-servers.png" class="img-fluid">
                                    </div>
                                    <!-- end img -->
                                    <ul>
                                        <li class="item-01">24X7 Telephone Support</li>
                                        <li class="item-02">Free Disk Mirroring with Hardware RAID</li>
                                        <li class="item-03">Perimeter Level Firewall</li>
                                    </ul>
                                </div>
                            <!-- end column -->
                            <div class="column">
                                <div class="img">
                                    <img src="img/server/dedicated-power-servers.png" class="img-fluid">
                                </div>
                                <!-- end img -->
                                <ul>
                                    <li class="item-04">Branded Server with RPS</li>
                                    <li class="item-05">Migration Assistance</li>
                                    <li class="item-06">Personal Relationship Manager</li>
                                </ul>
                            </div>
                            <!-- end colunm -->
                        </div>
                        <!-- end holder -->
                    </div>
                    <!-- end reasons -->

                        <div class="color-box" style="border: solid 1px #4CAF50;">
                            <a style="margin-top: 0px;    background: #4ab54d;" href="#plans-block" class="btn-select" title="Select a Plan">select a plan</a>
                            <p style=" padding-top: 5px; ">Plenty of reasons to get started. Just pick a plan and we’ll do the rest!</p>
                        </div>
                        <!-- end color box -->
                        <div class="list" style="background:none">
                            <h4 style="color: #021058">INCLUDED WITH ALL PLANS</h4>
                            <div class="folder">
                                <ol>
                                    <li>Full Root Level Access RDP desktop or Putty</li>
                                    <li>Unlimited Remote Hands support</li>
                                    <li>Perimeter level firewall, spam &amp; antivirus</li>
                                    <li>Peace of mind 99.995% high availability SLA</li>
                                </ol>
                                <ol>
                                    <li>100 Mbps Burstable bandwidth on a carrier neutral network</li>
                                    <li>Bandwidth usage with MRTG Graphs</li>
                                    <li>24 X 7 Direct Phone Support</li>
                                </ol>
                            </div>
                        </div>
                </div>
                    <div class="col-md-3">
                        <div class="box">
                        <div class="row">
                            <h6 style="color: #021058">Need help deciding?</h6>
                            <p>CONTACT US</p>
                        </div>
                            <div class="row">
                               
                                <div class="col-3">
                                    <i class="fa fa-headphones" aria-hidden="true"></i>
                                </div>
                                <div class="col-9"> 
                                        <p><b style="color: #021058">1800-102-8757</b></p>
                                        <p>Sales Toll Free Number</p>
                                </div>
                            </div> 
                           </div>
                        <div class="box mt-3">
                        <div class="row">
                            <h6 style="color: #021058">Sounds good?</h6>
                            <p>FILL UP THE FORM BELOW & GET ATTRACTIVE OFFERS</p>
                        </div>
                            <div class="row">
                               
                                <div class="col-12">
                                    <form action="/action_page.php">
                                         <div class="form-group">
                                        <label for="name">Name</label>
                                        <input type="name" class="form-control" id="name">
                                      </div>
                                      <div class="form-group">
                                        <label for="email"> Your Email address</label>
                                        <input type="email" class="form-control" id="email">
                                      </div>
                                      <div class="form-group">
                                        <label for="pwd">Phone Number</label>
                                        <input type="password" class="form-control" id="pwd">
                                      </div>
                                       <div class="form-group">
                                        <label for="pwd">Comments</label>
                                        <textarea type="password" class="form-control" id="pwd"></textarea>
                                      </div>
                                      <button type="submit" class="btn btn-primary btn-sm mb-4">Submit</button>
                                    </form>
                                </div>
                                
                            </div> 
                           </div>   

                           <div class="box mt-3">
                        <div class="row">
                            <h6 style="color: #021058">Other Category Products</h6>
                        </div>
                            <div class="row">
                                <div class="col-12" style="height: 357px;">
                                    <ul>
                                        <li class="border-bottom"><a href="power-servers.php" target="_blank" title="Power Servers">Power Servers</a><span>Super micro-based servers starting from dual-core upto 8GB of RAM and dual HDDs. Best suited for hosting.</span></li>
                                        <li class="border-bottom"><a href="virtualization-servers.php" target="_blank" title="Managed Virtualization Servers">Virtualization Servers</a><span>Managed Virtualization Servers</span></li>
                                        <li class="border-bottom"><a href="cloud-loadbalancer-clustering.php" target="_blank" title="Load Balancer, Cluster &amp; Firewall">Load Balancer, Cluster &amp; Firewall</a><span>Mirroring and failover service for traffic and load management on high-performance sites and server applications.</span></li>
                                    </ul>
                                </div>
                                
                            </div> 
                           </div>  
                        </div>

                    </div>
                 </div>

            </div>

        </div>
    </div>
    <!-- #####  ##### -->
   

    <!-- ##### Footer Area Start ##### -->
   <?php include('include/footer.php'); ?>
    <!-- ##### Footer Area Start ##### -->
    <!-- Modal -->
        <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <!-- <h5 class="modal-title" id="exampleModalLabel">Modal title</h5> -->
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                </button>
              </div>
              <div class="modal-body">
                <div id="form-div">
                  <h1 id="modal_title" class="mb-3">Request a Proposal</h1>
                  <div id="crmWebToEntityForm">
                  <meta http-equiv="content-type" content="text/html;charset=UTF-8">
                   <form action="https://crm.zoho.com/crm/WebToLeadForm" name="WebToLeads2569189000036872060" method="POST" onsubmit="javascript:document.charset=&quot;UTF-8&quot;; return checkMandatory2569189000036872060()" accept-charset="UTF-8">
                <input type="text" style="display:none;" name="xnQsjsdp" value="5bbf9f74877d7cbf151ef666b662b48a23ff284067d965528e240073aedb838e"> 
                 <input type="hidden" name="zc_gad" id="zc_gad" value="undefined"> 
                 <input type="text" style="display:none;" name="xmIwtLD" value="32ce659de9c603b6bad36dc19a4b92680016792428af0c36e0e96f992b153ff4"> 
                 <input type="text" style="display:none;" name="actionType" value="TGVhZHM=">
                <input type="text" style="display:none;" name="returnURL" value="https://www.ctrls.com/thankyou.php"> 



                      <div class="form-group row">
                        <label class="col-sm-4 col-form-label">Name<span style="color:red;">*</span></label>
                        <div class="col-sm-8"><input type="text" maxlength="80" name="Last Name" class="form-control textbox"></div>
                      </div>

                      <div class="form-group row">
                        <label class="col-sm-4 col-form-label">Email<span style="color:red;">*</span></label>
                        <div class="col-sm-8"><input type="text" maxlength="100" name="Email" id="email1" class="form-control textbox"></div>
                      </div>

                      <div class="form-group row">
                        <label class="col-sm-4 col-form-label">Phone<span style="color:red;">*</span></label>
                        <div class="col-sm-8"><input type="text" maxlength="30" name="Phone" id="telephone" class="form-control textbox"></div>
                      </div>

                      <div class="form-group row">
                        <label class="col-sm-4 col-form-label pr-0">Company Name</label>
                        <div class="col-sm-8">
                          <textarea name="Description" rows="3" maxlength="32000" class="form-control textbox">&nbsp;</textarea>
                        </div>
                      </div>

                      <div style="display:none;">
                        <label class="col-sm-4 col-form-label">Page URL</label>
                        <div class="col-sm-8">
                          <textarea name="LEADCF2" maxlength="2000" id="pageLocation">www.ctrls.com&nbsp;</textarea>
                        </div>
                      </div>

                      <div style="display:none;">
                        <label class="col-sm-4 col-form-label">Lead Source</label>
                        <div class="col-sm-8">
                          <select style="width:250px;" name="Lead Source">
                            <option value="-None-">-None-</option>
                            <option value="Cloud4C Google Ads">Cloud4C Google Ads</option>
                            <option value="Cloud4C.com">Cloud4C.com</option>
                            <option value="Cloud4C.com Google Adwords">Cloud4C.com Google Adwords</option>
                            <option value="Cloud4c.com LivServ">Cloud4c.com LivServ</option>
                            <option value="Cloud4C.com SalesIQ Chat">Cloud4C.com SalesIQ Chat</option>
                            <option value="Cloud4C.com Website">Cloud4C.com Website</option>
                            <option value="Colocation-ctrlS.com">Colocation-ctrlS.com</option>
                            <option value="Colocation-ctrlS.com - Chat">Colocation-ctrlS.com - Chat</option>
                            <option value="CtrlS Google Ads">CtrlS Google Ads</option>
                            <option value="CtrlS.com">CtrlS.com</option>
                            <option value="CtrlS.com - Data Center">CtrlS.com - Data Center</option>
                            <option value="CtrlS.com - Data Center - Chat">CtrlS.com - Data Center - Chat</option>
                            <option value="CtrlS.com Google Adwords">CtrlS.com Google Adwords</option>
                            <option value="CtrlS.com SalesIQ Chat">CtrlS.com SalesIQ Chat</option>
                            <option selected="" value="CtrlS.com Website">CtrlS.com Website</option>
                            <option value="Ctrls.in Chat">Ctrls.in Chat</option>
                            <option value="CtrlS.in SalesIQ Chat">CtrlS.in SalesIQ Chat</option>
                            <option value="CtrlS.in Website">CtrlS.in Website</option>
                            <option value="Downloads Cloud4C">Downloads Cloud4C</option>
                            <option value="Downloads CtrlS">Downloads CtrlS</option>
                            <option value="Email Marketing">Email Marketing</option>
                            <option value="Form Fills Cloud4C">Form Fills Cloud4C</option>
                            <option value="Form Fills CtrlS">Form Fills CtrlS</option>
                            <option value="Human Resource">Human Resource</option>
                            <option value="Linkedin">Linkedin</option>
                            <option value="Managed services - Facebook">Managed services - Facebook</option>
                            <option value="Managed services - Google">Managed services - Google</option>
                            <option value="Marketing Cloud4C">Marketing Cloud4C</option>
                            <option value="Marketing CtrlS">Marketing CtrlS</option>
                            <option value="Publishers">Publishers</option>
                            <option value="Referrals">Referrals</option>
                            <option value="Registration">Registration</option>
                            <option value="Toll Free Cloud4C">Toll Free Cloud4C</option>
                            <option value="Toll Free CtrlS">Toll Free CtrlS</option>
                          </select>
                        </div>
                      </div>

                      <div style="display:none;">
                        <label class="col-sm-4 col-form-label">Paid Identifier</label>
                        <div class="col-sm-8">
                        <select style="width:250px;" name="LEADCF14">
                          <option value="-None-">-None-</option>
                          <option value="Paid">Paid</option>
                          <option selected="" value="Non Paid">Non Paid</option>
                        </select>
                        </div>
                      </div>

                  <div class="form-group row">
                    <label class="col-sm-4 col-form-label">Enter the Captcha</label>
                    <div class="col-sm-8">
                      <input type="text" maxlength="80" name="enterdigest" id="captcha" class="form-control">
                      <div class="mt-2 mb-3">
                        <img id="imgid" src="https://crm.zoho.com/crm/CaptchaServlet?formId=32ce659de9c603b6bad36dc19a4b92680016792428af0c36e0e96f992b153ff4&amp;grpid=5bbf9f74877d7cbf151ef666b662b48a23ff284067d965528e240073aedb838e"> 
                        <a href="javascript:;" onclick="reloadImg()">Reload</a>
                      </div>
                      <input id="formsubmit" type="submit" value="Submit" class="btn btn-submit">
                    </div>
                  </div>
      
              <script>
                var mndFileds=new Array('Last Name','Email','Phone');
                var fldLangVal=new Array('Name','Email','Phone'); 
                var name='';
                var email='';
                
                /* Do not remove this code. */
                function reloadImg() {
                  if(document.getElementById('imgid').src.indexOf('&d') !== -1 ) {
                    document.getElementById('imgid').src=document.getElementById('imgid').src.substring(0,document.getElementById('imgid').src.indexOf('&d'))+'&d'+new Date().getTime();
                  }  else {
                    document.getElementById('imgid').src = document.getElementById('imgid').src+'&d'+new Date().getTime();
                  } 
                }

                function checkMandatory2569189000036872060() {
                  for(i=0;i<mndFileds.length;i++) {
                    var fieldObj=document.forms['WebToLeads2569189000036872060'][mndFileds[i]];
                    if(fieldObj) {
                      if (((fieldObj.value).replace(/^\s+|\s+$/g, '')).length==0) {
                      if(fieldObj.type =='file'){
                                  alert('Please select a file to upload.');
                                  fieldObj.focus();
                                  return false;
                              }
                              $(fieldObj).addClass('error');
                              fieldObj.focus();
                              setTimeout(function(){ 
                                  alert(fldLangVal[i] +' cannot be empty.');
                              }, 500);
                              return false;
                          }  else if(fieldObj.nodeName=='SELECT') {
                              if(fieldObj.options[fieldObj.selectedIndex].value=='-None-') {
                                  alert(fldLangVal[i] +' cannot be none.');
                                  fieldObj.focus();
                                  return false;
                              }
                          } else if(fieldObj.type =='checkbox'){
                              if(fieldObj.checked == false){
                                  alert('Please accept  '+fldLangVal[i]);
                                  fieldObj.focus();
                                  return false;
                              }
                          } else if (fieldObj.name === "Phone") {
                              if (!isPhone(fieldObj.value)) {
                                  $("#telephone").focus();
                                  alert("Please enter valid Phone Number");
                                  return false;
                              }
                          } else if (fieldObj.name === "Email") {
                              if (!isEmail(fieldObj.value)) {
                                  $("#email1").focus();
                                  alert("Please enter valid email address");
                                  return false;
                              }
                          }
                          try {
                              if(fieldObj.name == 'Last Name') {
                                  name = fieldObj.value;
                              }
                          } catch (e) {
              
                          }
                      }
                  }
                  if($('#captcha').val() == "") {
                      alert("Please enter below code");
                      return false;
                  } else {
                      //alert("Thank you");
                  }
                  
                  setTimeout(function(){
                    window.parent.fancyboxCloser();
                  }, 100);
                  document.getElementById('formsubmit').disabled=true;
                  }
                </script>
              </form>
          <!-- Do not remove this code. -->
             <iframe name="captchaFrame" style="display:none;"></iframe>
        </div>
        </div>
              </div>
            </div>
          </div>
        </div>
        <!-- Modal1 -->
        <div class="modal fade" id="exampleModal1" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <!-- <h5 class="modal-title" id="exampleModalLabel">Modal title</h5> -->
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                </button>
              </div>
              <div class="modal-body">
                <div id="form-div">
  <h1 id="modal_title" class="mb-3">Request a Proposal</h1>
  <div id="crmWebToEntityForm">
  <meta http-equiv="content-type" content="text/html;charset=UTF-8">
   <form action="https://crm.zoho.com/crm/WebToLeadForm" name="WebToLeads2569189000036872060" method="POST" onsubmit="javascript:document.charset=&quot;UTF-8&quot;; return checkMandatory2569189000036872060()" accept-charset="UTF-8">
<input type="text" style="display:none;" name="xnQsjsdp" value="5bbf9f74877d7cbf151ef666b662b48a23ff284067d965528e240073aedb838e"> 
 <input type="hidden" name="zc_gad" id="zc_gad" value="undefined"> 
 <input type="text" style="display:none;" name="xmIwtLD" value="32ce659de9c603b6bad36dc19a4b92680016792428af0c36e0e96f992b153ff4"> 
 <input type="text" style="display:none;" name="actionType" value="TGVhZHM=">
<input type="text" style="display:none;" name="returnURL" value="https://www.ctrls.com/thankyou.php"> 



      <div class="form-group row">
        <label class="col-sm-4 col-form-label">Name<span style="color:red;">*</span></label>
        <div class="col-sm-8"><input type="text" maxlength="80" name="Last Name" class="form-control textbox"></div>
      </div>

      <div class="form-group row">
        <label class="col-sm-4 col-form-label">Email<span style="color:red;">*</span></label>
        <div class="col-sm-8"><input type="text" maxlength="100" name="Email" id="email1" class="form-control textbox"></div>
      </div>

      <div class="form-group row">
        <label class="col-sm-4 col-form-label">Phone<span style="color:red;">*</span></label>
        <div class="col-sm-8"><input type="text" maxlength="30" name="Phone" id="telephone" class="form-control textbox"></div>
      </div>

      <div class="form-group row">
        <label class="col-sm-4 col-form-label pr-0">Company Name</label>
        <div class="col-sm-8">
          <textarea name="Description" rows="3" maxlength="32000" class="form-control textbox">&nbsp;</textarea>
        </div>
      </div>

      <div style="display:none;">
        <label class="col-sm-4 col-form-label">Page URL</label>
        <div class="col-sm-8">
          <textarea name="LEADCF2" maxlength="2000" id="pageLocation">www.ctrls.com&nbsp;</textarea>
        </div>
      </div>

      <div style="display:none;">
        <label class="col-sm-4 col-form-label">Lead Source</label>
        <div class="col-sm-8">
          <select style="width:250px;" name="Lead Source">
            <option value="-None-">-None-</option>
            <option value="Cloud4C Google Ads">Cloud4C Google Ads</option>
            <option value="Cloud4C.com">Cloud4C.com</option>
            <option value="Cloud4C.com Google Adwords">Cloud4C.com Google Adwords</option>
            <option value="Cloud4c.com LivServ">Cloud4c.com LivServ</option>
            <option value="Cloud4C.com SalesIQ Chat">Cloud4C.com SalesIQ Chat</option>
            <option value="Cloud4C.com Website">Cloud4C.com Website</option>
            <option value="Colocation-ctrlS.com">Colocation-ctrlS.com</option>
            <option value="Colocation-ctrlS.com - Chat">Colocation-ctrlS.com - Chat</option>
            <option value="CtrlS Google Ads">CtrlS Google Ads</option>
            <option value="CtrlS.com">CtrlS.com</option>
            <option value="CtrlS.com - Data Center">CtrlS.com - Data Center</option>
            <option value="CtrlS.com - Data Center - Chat">CtrlS.com - Data Center - Chat</option>
            <option value="CtrlS.com Google Adwords">CtrlS.com Google Adwords</option>
            <option value="CtrlS.com SalesIQ Chat">CtrlS.com SalesIQ Chat</option>
            <option selected="" value="CtrlS.com Website">CtrlS.com Website</option>
            <option value="Ctrls.in Chat">Ctrls.in Chat</option>
            <option value="CtrlS.in SalesIQ Chat">CtrlS.in SalesIQ Chat</option>
            <option value="CtrlS.in Website">CtrlS.in Website</option>
            <option value="Downloads Cloud4C">Downloads Cloud4C</option>
            <option value="Downloads CtrlS">Downloads CtrlS</option>
            <option value="Email Marketing">Email Marketing</option>
            <option value="Form Fills Cloud4C">Form Fills Cloud4C</option>
            <option value="Form Fills CtrlS">Form Fills CtrlS</option>
            <option value="Human Resource">Human Resource</option>
            <option value="Linkedin">Linkedin</option>
            <option value="Managed services - Facebook">Managed services - Facebook</option>
            <option value="Managed services - Google">Managed services - Google</option>
            <option value="Marketing Cloud4C">Marketing Cloud4C</option>
            <option value="Marketing CtrlS">Marketing CtrlS</option>
            <option value="Publishers">Publishers</option>
            <option value="Referrals">Referrals</option>
            <option value="Registration">Registration</option>
            <option value="Toll Free Cloud4C">Toll Free Cloud4C</option>
            <option value="Toll Free CtrlS">Toll Free CtrlS</option>
          </select>
        </div>
      </div>

      <div style="display:none;">
        <label class="col-sm-4 col-form-label">Paid Identifier</label>
        <div class="col-sm-8">
        <select style="width:250px;" name="LEADCF14">
          <option value="-None-">-None-</option>
          <option value="Paid">Paid</option>
          <option selected="" value="Non Paid">Non Paid</option>
        </select>
        </div>
      </div>

      <div class="form-group row">
        <label class="col-sm-4 col-form-label">Enter the Captcha</label>
        <div class="col-sm-8">
          <input type="text" maxlength="80" name="enterdigest" id="captcha" class="form-control">
          <div class="mt-2 mb-3">
            <img id="imgid" src="https://crm.zoho.com/crm/CaptchaServlet?formId=32ce659de9c603b6bad36dc19a4b92680016792428af0c36e0e96f992b153ff4&amp;grpid=5bbf9f74877d7cbf151ef666b662b48a23ff284067d965528e240073aedb838e"> 
            <a href="javascript:;" onclick="reloadImg()">Reload</a>
          </div>
          <input id="formsubmit" type="submit" value="Submit" class="btn btn-submit">
        </div>
      </div>
      
      <script>
        var mndFileds=new Array('Last Name','Email','Phone');
        var fldLangVal=new Array('Name','Email','Phone'); 
        var name='';
        var email='';
        
        /* Do not remove this code. */
        function reloadImg() {
          if(document.getElementById('imgid').src.indexOf('&d') !== -1 ) {
            document.getElementById('imgid').src=document.getElementById('imgid').src.substring(0,document.getElementById('imgid').src.indexOf('&d'))+'&d'+new Date().getTime();
          }  else {
            document.getElementById('imgid').src = document.getElementById('imgid').src+'&d'+new Date().getTime();
          } 
        }

        function checkMandatory2569189000036872060() {
          for(i=0;i<mndFileds.length;i++) {
            var fieldObj=document.forms['WebToLeads2569189000036872060'][mndFileds[i]];
            if(fieldObj) {
              if (((fieldObj.value).replace(/^\s+|\s+$/g, '')).length==0) {
              if(fieldObj.type =='file'){
                          alert('Please select a file to upload.');
                          fieldObj.focus();
                          return false;
                      }
                      $(fieldObj).addClass('error');
                      fieldObj.focus();
                      setTimeout(function(){ 
                          alert(fldLangVal[i] +' cannot be empty.');
                      }, 500);
                      return false;
                  }  else if(fieldObj.nodeName=='SELECT') {
                      if(fieldObj.options[fieldObj.selectedIndex].value=='-None-') {
                          alert(fldLangVal[i] +' cannot be none.');
                          fieldObj.focus();
                          return false;
                      }
                  } else if(fieldObj.type =='checkbox'){
                      if(fieldObj.checked == false){
                          alert('Please accept  '+fldLangVal[i]);
                          fieldObj.focus();
                          return false;
                      }
                  } else if (fieldObj.name === "Phone") {
                      if (!isPhone(fieldObj.value)) {
                          $("#telephone").focus();
                          alert("Please enter valid Phone Number");
                          return false;
                      }
                  } else if (fieldObj.name === "Email") {
                      if (!isEmail(fieldObj.value)) {
                          $("#email1").focus();
                          alert("Please enter valid email address");
                          return false;
                      }
                  }
                  try {
                      if(fieldObj.name == 'Last Name') {
                          name = fieldObj.value;
                      }
                  } catch (e) {
      
                  }
              }
          }
          if($('#captcha').val() == "") {
              alert("Please enter below code");
              return false;
          } else {
              //alert("Thank you");
          }
          
          setTimeout(function(){
            window.parent.fancyboxCloser();
          }, 100);
          document.getElementById('formsubmit').disabled=true;
          }
        </script>
      </form>
  <!-- Do not remove this code. -->
     <iframe name="captchaFrame" style="display:none;"></iframe>
</div>
</div>
              </div>
              <!-- <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <button type="button" class="btn btn-primary">Save changes</button>
              </div> -->
            </div>
          </div>
        </div>
        <!-- Modal2 -->
        <div class="modal fade" id="exampleModal2" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <!-- <h5 class="modal-title" id="exampleModalLabel">Modal title</h5> -->
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                </button>
              </div>
              <div class="modal-body">
                <div id="form-div">
  <h1 id="modal_title" class="mb-3">Request a Proposal</h1>
  <div id="crmWebToEntityForm">
  <meta http-equiv="content-type" content="text/html;charset=UTF-8">
   <form action="https://crm.zoho.com/crm/WebToLeadForm" name="WebToLeads2569189000036872060" method="POST" onsubmit="javascript:document.charset=&quot;UTF-8&quot;; return checkMandatory2569189000036872060()" accept-charset="UTF-8">
<input type="text" style="display:none;" name="xnQsjsdp" value="5bbf9f74877d7cbf151ef666b662b48a23ff284067d965528e240073aedb838e"> 
 <input type="hidden" name="zc_gad" id="zc_gad" value="undefined"> 
 <input type="text" style="display:none;" name="xmIwtLD" value="32ce659de9c603b6bad36dc19a4b92680016792428af0c36e0e96f992b153ff4"> 
 <input type="text" style="display:none;" name="actionType" value="TGVhZHM=">
<input type="text" style="display:none;" name="returnURL" value="https://www.ctrls.com/thankyou.php"> 



      <div class="form-group row">
        <label class="col-sm-4 col-form-label">Name<span style="color:red;">*</span></label>
        <div class="col-sm-8"><input type="text" maxlength="80" name="Last Name" class="form-control textbox"></div>
      </div>

      <div class="form-group row">
        <label class="col-sm-4 col-form-label">Email<span style="color:red;">*</span></label>
        <div class="col-sm-8"><input type="text" maxlength="100" name="Email" id="email1" class="form-control textbox"></div>
      </div>

      <div class="form-group row">
        <label class="col-sm-4 col-form-label">Phone<span style="color:red;">*</span></label>
        <div class="col-sm-8"><input type="text" maxlength="30" name="Phone" id="telephone" class="form-control textbox"></div>
      </div>

      <div class="form-group row">
        <label class="col-sm-4 col-form-label pr-0">Company Name</label>
        <div class="col-sm-8">
          <textarea name="Description" rows="3" maxlength="32000" class="form-control textbox">&nbsp;</textarea>
        </div>
      </div>

      <div style="display:none;">
        <label class="col-sm-4 col-form-label">Page URL</label>
        <div class="col-sm-8">
          <textarea name="LEADCF2" maxlength="2000" id="pageLocation">www.ctrls.com&nbsp;</textarea>
        </div>
      </div>

      <div style="display:none;">
        <label class="col-sm-4 col-form-label">Lead Source</label>
        <div class="col-sm-8">
          <select style="width:250px;" name="Lead Source">
            <option value="-None-">-None-</option>
            <option value="Cloud4C Google Ads">Cloud4C Google Ads</option>
            <option value="Cloud4C.com">Cloud4C.com</option>
            <option value="Cloud4C.com Google Adwords">Cloud4C.com Google Adwords</option>
            <option value="Cloud4c.com LivServ">Cloud4c.com LivServ</option>
            <option value="Cloud4C.com SalesIQ Chat">Cloud4C.com SalesIQ Chat</option>
            <option value="Cloud4C.com Website">Cloud4C.com Website</option>
            <option value="Colocation-ctrlS.com">Colocation-ctrlS.com</option>
            <option value="Colocation-ctrlS.com - Chat">Colocation-ctrlS.com - Chat</option>
            <option value="CtrlS Google Ads">CtrlS Google Ads</option>
            <option value="CtrlS.com">CtrlS.com</option>
            <option value="CtrlS.com - Data Center">CtrlS.com - Data Center</option>
            <option value="CtrlS.com - Data Center - Chat">CtrlS.com - Data Center - Chat</option>
            <option value="CtrlS.com Google Adwords">CtrlS.com Google Adwords</option>
            <option value="CtrlS.com SalesIQ Chat">CtrlS.com SalesIQ Chat</option>
            <option selected="" value="CtrlS.com Website">CtrlS.com Website</option>
            <option value="Ctrls.in Chat">Ctrls.in Chat</option>
            <option value="CtrlS.in SalesIQ Chat">CtrlS.in SalesIQ Chat</option>
            <option value="CtrlS.in Website">CtrlS.in Website</option>
            <option value="Downloads Cloud4C">Downloads Cloud4C</option>
            <option value="Downloads CtrlS">Downloads CtrlS</option>
            <option value="Email Marketing">Email Marketing</option>
            <option value="Form Fills Cloud4C">Form Fills Cloud4C</option>
            <option value="Form Fills CtrlS">Form Fills CtrlS</option>
            <option value="Human Resource">Human Resource</option>
            <option value="Linkedin">Linkedin</option>
            <option value="Managed services - Facebook">Managed services - Facebook</option>
            <option value="Managed services - Google">Managed services - Google</option>
            <option value="Marketing Cloud4C">Marketing Cloud4C</option>
            <option value="Marketing CtrlS">Marketing CtrlS</option>
            <option value="Publishers">Publishers</option>
            <option value="Referrals">Referrals</option>
            <option value="Registration">Registration</option>
            <option value="Toll Free Cloud4C">Toll Free Cloud4C</option>
            <option value="Toll Free CtrlS">Toll Free CtrlS</option>
          </select>
        </div>
      </div>

      <div style="display:none;">
        <label class="col-sm-4 col-form-label">Paid Identifier</label>
        <div class="col-sm-8">
        <select style="width:250px;" name="LEADCF14">
          <option value="-None-">-None-</option>
          <option value="Paid">Paid</option>
          <option selected="" value="Non Paid">Non Paid</option>
        </select>
        </div>
      </div>

      <div class="form-group row">
        <label class="col-sm-4 col-form-label">Enter the Captcha</label>
        <div class="col-sm-8">
          <input type="text" maxlength="80" name="enterdigest" id="captcha" class="form-control">
          <div class="mt-2 mb-3">
            <img id="imgid" src="https://crm.zoho.com/crm/CaptchaServlet?formId=32ce659de9c603b6bad36dc19a4b92680016792428af0c36e0e96f992b153ff4&amp;grpid=5bbf9f74877d7cbf151ef666b662b48a23ff284067d965528e240073aedb838e"> 
            <a href="javascript:;" onclick="reloadImg()">Reload</a>
          </div>
          <input id="formsubmit" type="submit" value="Submit" class="btn btn-submit">
        </div>
      </div>
      
      <script>
        var mndFileds=new Array('Last Name','Email','Phone');
        var fldLangVal=new Array('Name','Email','Phone'); 
        var name='';
        var email='';
        
        /* Do not remove this code. */
        function reloadImg() {
          if(document.getElementById('imgid').src.indexOf('&d') !== -1 ) {
            document.getElementById('imgid').src=document.getElementById('imgid').src.substring(0,document.getElementById('imgid').src.indexOf('&d'))+'&d'+new Date().getTime();
          }  else {
            document.getElementById('imgid').src = document.getElementById('imgid').src+'&d'+new Date().getTime();
          } 
        }

        function checkMandatory2569189000036872060() {
          for(i=0;i<mndFileds.length;i++) {
            var fieldObj=document.forms['WebToLeads2569189000036872060'][mndFileds[i]];
            if(fieldObj) {
              if (((fieldObj.value).replace(/^\s+|\s+$/g, '')).length==0) {
              if(fieldObj.type =='file'){
                          alert('Please select a file to upload.');
                          fieldObj.focus();
                          return false;
                      }
                      $(fieldObj).addClass('error');
                      fieldObj.focus();
                      setTimeout(function(){ 
                          alert(fldLangVal[i] +' cannot be empty.');
                      }, 500);
                      return false;
                  }  else if(fieldObj.nodeName=='SELECT') {
                      if(fieldObj.options[fieldObj.selectedIndex].value=='-None-') {
                          alert(fldLangVal[i] +' cannot be none.');
                          fieldObj.focus();
                          return false;
                      }
                  } else if(fieldObj.type =='checkbox'){
                      if(fieldObj.checked == false){
                          alert('Please accept  '+fldLangVal[i]);
                          fieldObj.focus();
                          return false;
                      }
                  } else if (fieldObj.name === "Phone") {
                      if (!isPhone(fieldObj.value)) {
                          $("#telephone").focus();
                          alert("Please enter valid Phone Number");
                          return false;
                      }
                  } else if (fieldObj.name === "Email") {
                      if (!isEmail(fieldObj.value)) {
                          $("#email1").focus();
                          alert("Please enter valid email address");
                          return false;
                      }
                  }
                  try {
                      if(fieldObj.name == 'Last Name') {
                          name = fieldObj.value;
                      }
                  } catch (e) {
      
                  }
              }
          }
          if($('#captcha').val() == "") {
              alert("Please enter below code");
              return false;
          } else {
              //alert("Thank you");
          }
          
          setTimeout(function(){
            window.parent.fancyboxCloser();
          }, 100);
          document.getElementById('formsubmit').disabled=true;
          }
        </script>
      </form>
  <!-- Do not remove this code. -->
     <iframe name="captchaFrame" style="display:none;"></iframe>
</div>
</div>
              </div>
              <!-- <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <button type="button" class="btn btn-primary">Save changes</button>
              </div> -->
            </div>
          </div>
        </div>
        <!-- Modal3 -->
        <div class="modal fade" id="exampleModal3" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <!-- <h5 class="modal-title" id="exampleModalLabel">Modal title</h5> -->
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                </button>
              </div>
              <div class="modal-body">
                <div id="form-div">
  <h1 id="modal_title" class="mb-3">Request a Proposal</h1>
  <div id="crmWebToEntityForm">
  <meta http-equiv="content-type" content="text/html;charset=UTF-8">
   <form action="https://crm.zoho.com/crm/WebToLeadForm" name="WebToLeads2569189000036872060" method="POST" onsubmit="javascript:document.charset=&quot;UTF-8&quot;; return checkMandatory2569189000036872060()" accept-charset="UTF-8">
<input type="text" style="display:none;" name="xnQsjsdp" value="5bbf9f74877d7cbf151ef666b662b48a23ff284067d965528e240073aedb838e"> 
 <input type="hidden" name="zc_gad" id="zc_gad" value="undefined"> 
 <input type="text" style="display:none;" name="xmIwtLD" value="32ce659de9c603b6bad36dc19a4b92680016792428af0c36e0e96f992b153ff4"> 
 <input type="text" style="display:none;" name="actionType" value="TGVhZHM=">
<input type="text" style="display:none;" name="returnURL" value="https://www.ctrls.com/thankyou.php"> 



      <div class="form-group row">
        <label class="col-sm-4 col-form-label">Name<span style="color:red;">*</span></label>
        <div class="col-sm-8"><input type="text" maxlength="80" name="Last Name" class="form-control textbox"></div>
      </div>

      <div class="form-group row">
        <label class="col-sm-4 col-form-label">Email<span style="color:red;">*</span></label>
        <div class="col-sm-8"><input type="text" maxlength="100" name="Email" id="email1" class="form-control textbox"></div>
      </div>

      <div class="form-group row">
        <label class="col-sm-4 col-form-label">Phone<span style="color:red;">*</span></label>
        <div class="col-sm-8"><input type="text" maxlength="30" name="Phone" id="telephone" class="form-control textbox"></div>
      </div>

      <div class="form-group row">
        <label class="col-sm-4 col-form-label pr-0">Company Name</label>
        <div class="col-sm-8">
          <textarea name="Description" rows="3" maxlength="32000" class="form-control textbox">&nbsp;</textarea>
        </div>
      </div>

      <div style="display:none;">
        <label class="col-sm-4 col-form-label">Page URL</label>
        <div class="col-sm-8">
          <textarea name="LEADCF2" maxlength="2000" id="pageLocation">www.ctrls.com&nbsp;</textarea>
        </div>
      </div>

      <div style="display:none;">
        <label class="col-sm-4 col-form-label">Lead Source</label>
        <div class="col-sm-8">
          <select style="width:250px;" name="Lead Source">
            <option value="-None-">-None-</option>
            <option value="Cloud4C Google Ads">Cloud4C Google Ads</option>
            <option value="Cloud4C.com">Cloud4C.com</option>
            <option value="Cloud4C.com Google Adwords">Cloud4C.com Google Adwords</option>
            <option value="Cloud4c.com LivServ">Cloud4c.com LivServ</option>
            <option value="Cloud4C.com SalesIQ Chat">Cloud4C.com SalesIQ Chat</option>
            <option value="Cloud4C.com Website">Cloud4C.com Website</option>
            <option value="Colocation-ctrlS.com">Colocation-ctrlS.com</option>
            <option value="Colocation-ctrlS.com - Chat">Colocation-ctrlS.com - Chat</option>
            <option value="CtrlS Google Ads">CtrlS Google Ads</option>
            <option value="CtrlS.com">CtrlS.com</option>
            <option value="CtrlS.com - Data Center">CtrlS.com - Data Center</option>
            <option value="CtrlS.com - Data Center - Chat">CtrlS.com - Data Center - Chat</option>
            <option value="CtrlS.com Google Adwords">CtrlS.com Google Adwords</option>
            <option value="CtrlS.com SalesIQ Chat">CtrlS.com SalesIQ Chat</option>
            <option selected="" value="CtrlS.com Website">CtrlS.com Website</option>
            <option value="Ctrls.in Chat">Ctrls.in Chat</option>
            <option value="CtrlS.in SalesIQ Chat">CtrlS.in SalesIQ Chat</option>
            <option value="CtrlS.in Website">CtrlS.in Website</option>
            <option value="Downloads Cloud4C">Downloads Cloud4C</option>
            <option value="Downloads CtrlS">Downloads CtrlS</option>
            <option value="Email Marketing">Email Marketing</option>
            <option value="Form Fills Cloud4C">Form Fills Cloud4C</option>
            <option value="Form Fills CtrlS">Form Fills CtrlS</option>
            <option value="Human Resource">Human Resource</option>
            <option value="Linkedin">Linkedin</option>
            <option value="Managed services - Facebook">Managed services - Facebook</option>
            <option value="Managed services - Google">Managed services - Google</option>
            <option value="Marketing Cloud4C">Marketing Cloud4C</option>
            <option value="Marketing CtrlS">Marketing CtrlS</option>
            <option value="Publishers">Publishers</option>
            <option value="Referrals">Referrals</option>
            <option value="Registration">Registration</option>
            <option value="Toll Free Cloud4C">Toll Free Cloud4C</option>
            <option value="Toll Free CtrlS">Toll Free CtrlS</option>
          </select>
        </div>
      </div>

      <div style="display:none;">
        <label class="col-sm-4 col-form-label">Paid Identifier</label>
        <div class="col-sm-8">
        <select style="width:250px;" name="LEADCF14">
          <option value="-None-">-None-</option>
          <option value="Paid">Paid</option>
          <option selected="" value="Non Paid">Non Paid</option>
        </select>
        </div>
      </div>

      <div class="form-group row">
        <label class="col-sm-4 col-form-label">Enter the Captcha</label>
        <div class="col-sm-8">
          <input type="text" maxlength="80" name="enterdigest" id="captcha" class="form-control">
          <div class="mt-2 mb-3">
            <img id="imgid" src="https://crm.zoho.com/crm/CaptchaServlet?formId=32ce659de9c603b6bad36dc19a4b92680016792428af0c36e0e96f992b153ff4&amp;grpid=5bbf9f74877d7cbf151ef666b662b48a23ff284067d965528e240073aedb838e"> 
            <a href="javascript:;" onclick="reloadImg()">Reload</a>
          </div>
          <input id="formsubmit" type="submit" value="Submit" class="btn btn-submit">
        </div>
      </div>
      
      <script>
        var mndFileds=new Array('Last Name','Email','Phone');
        var fldLangVal=new Array('Name','Email','Phone'); 
        var name='';
        var email='';
        
        /* Do not remove this code. */
        function reloadImg() {
          if(document.getElementById('imgid').src.indexOf('&d') !== -1 ) {
            document.getElementById('imgid').src=document.getElementById('imgid').src.substring(0,document.getElementById('imgid').src.indexOf('&d'))+'&d'+new Date().getTime();
          }  else {
            document.getElementById('imgid').src = document.getElementById('imgid').src+'&d'+new Date().getTime();
          } 
        }

        function checkMandatory2569189000036872060() {
          for(i=0;i<mndFileds.length;i++) {
            var fieldObj=document.forms['WebToLeads2569189000036872060'][mndFileds[i]];
            if(fieldObj) {
              if (((fieldObj.value).replace(/^\s+|\s+$/g, '')).length==0) {
              if(fieldObj.type =='file'){
                          alert('Please select a file to upload.');
                          fieldObj.focus();
                          return false;
                      }
                      $(fieldObj).addClass('error');
                      fieldObj.focus();
                      setTimeout(function(){ 
                          alert(fldLangVal[i] +' cannot be empty.');
                      }, 500);
                      return false;
                  }  else if(fieldObj.nodeName=='SELECT') {
                      if(fieldObj.options[fieldObj.selectedIndex].value=='-None-') {
                          alert(fldLangVal[i] +' cannot be none.');
                          fieldObj.focus();
                          return false;
                      }
                  } else if(fieldObj.type =='checkbox'){
                      if(fieldObj.checked == false){
                          alert('Please accept  '+fldLangVal[i]);
                          fieldObj.focus();
                          return false;
                      }
                  } else if (fieldObj.name === "Phone") {
                      if (!isPhone(fieldObj.value)) {
                          $("#telephone").focus();
                          alert("Please enter valid Phone Number");
                          return false;
                      }
                  } else if (fieldObj.name === "Email") {
                      if (!isEmail(fieldObj.value)) {
                          $("#email1").focus();
                          alert("Please enter valid email address");
                          return false;
                      }
                  }
                  try {
                      if(fieldObj.name == 'Last Name') {
                          name = fieldObj.value;
                      }
                  } catch (e) {
      
                  }
              }
          }
          if($('#captcha').val() == "") {
              alert("Please enter below code");
              return false;
          } else {
              //alert("Thank you");
          }
          
          setTimeout(function(){
            window.parent.fancyboxCloser();
          }, 100);
          document.getElementById('formsubmit').disabled=true;
          }
        </script>
      </form>
  <!-- Do not remove this code. -->
     <iframe name="captchaFrame" style="display:none;"></iframe>
</div>
</div>
              </div>
              <!-- <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <button type="button" class="btn btn-primary">Save changes</button>
              </div> -->
            </div>
          </div>
        </div>
    <!-- ##### All Javascript Script ##### -->
    <!-- jQuery-2.2.4 js -->
    <script src="js/jquery/jquery-2.2.4.min.js"></script>
    <!-- Popper js -->
    <script src="js/bootstrap/popper.min.js"></script>
    <!-- Bootstrap js -->
    <script src="js/bootstrap/bootstrap.min.js"></script>
    <!-- All Plugins js -->
    <script src="js/plugins/plugins.js"></script>
    <!-- Active js -->
    <script src="js/active.js"></script>
</body>

</html>