<!DOCTYPE html>
<html lang="en">

 <?php include('include/head.php'); ?>
<style>
    td{
        text-align:center;
    }
     table, td, th {
     border: 1px dotted;
     padding:8px;
    
    }
    
    #table1 {
      border-collapse: separate;
    }

</style>
<body>
    <!-- ##### Preloader ##### -->
    <div id="preloader">
        <i class="circle-preloader"></i>
    </div>

    <!-- ##### Header Area Start ##### -->
   <?php include('include/header.php'); ?>
    <!-- ##### Header Area End ##### -->

    <!-- ##### Hero Area Start ##### -->
         <section>
            <div class="single-hero-slide1 mt-4 bg2-img">
 
                <div class="container h-100">
                    <div class="row h-100 align-items-center">
                        <div class="col-12">
                            <div class="hero-slides-content">
                            <h3 class="text-dark heading pb-2">Work Area Recovery (BCP SEATS)</h3>
                            <p class="text-justify">Discovering what risks need to be avoided immediately. Examining the processes, <br>policies and procedures for their efficacy.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- ##### Hero Area End ##### -->
    
        <section>
            <nav aria-label="breadcrumb">
              <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                <li class="breadcrumb-item active" aria-current="page"><a href="business.php">Business Solution</a></li>
                <li class="breadcrumb-item">Work Area
                    Recovery (BCP SEATS)</li>
              </ol>
            </nav>
        </section>
   
    <!-- ##### ##### -->
    <div class="partner-area pt-5">
        <div class="container">
                 <div class="row">
                    <div class="col-md-9">
                        <div class="row p-3" style="border-top: 2px dotted #80808059;">
                           <div class="col-12">                              
                            <h6 style="color: #021058">HOW PREPARED IS YOUR ORGANIZATION IN THE EVENT OF A DISASTER?</h6>
                                <ul>
                                    <li class="text-justify">Being prepared for a disruption is natural. As individuals, we generally have a plan for alternate resources to be activated in the case of disruptions or excegencies such as …… Flat Tires, Rains, bad weather, etc. This is a smart business standard that prepares for a “what if” scenario.</li><br>
                                    <li class="text-justify">In a world where uncertainties abound, it is imperative for every business to have a business continuity plan ready. Heightened exposure to disruptive and catastrophic events in recent years coupled with increasing government and commercial interdependencies make disaster recovery and crisis management a critical business imperative. Any interruption in operations represents potential losses in revenue, opportunity and reputation.</li><br>
                                </ul>
                          </div>
                          <div class="col-12">                              
                            <h6 style="color: #021058">The statistics tell the story:</h6>
                                <ul>
                                    <li class="text-justify">“43% of companies experiencing disasters never re-open, and 29% close within two years,” McGladrey and Pullen.</li><br>
                                    <li class="text-justify">40% of all companies that experience a major disaster will go out of business if they cannot gain access to their data within 24 hours.” Gartner</li><br>
                                    <li class="text-justify">In all the chaos that ensues a disaster, one area that is often overlooked is IT Disaster Recovery. What does this mean? It means how your organization deals with and prevents IT downtime. Even if every other part of your business continuity plan is executed perfectly, you remain at a standstill if your IT systems go down and stay down.</li><br>
                                    <li class="text-justify">Aries helps businesses plan for, survive and prosper in spite of unexpected shutdowns. We help our clients to mitigate the IT risks they face by proactively providing alternatives to follow in case of unforeseen circumstances. We intend to make the shutdowns expected and planned for, therby reducing the cost if and when it occurs.</li><br>
                                </ul>
                          </div>
                          <div class="col-12">                              
                            <h6 style="color: #021058">Benefits to the business leaders is not only to save money and preserve wealth, but also other benefits such as:</h6>
                                <ul>
                                    <li class="text-justify">Discovering what risks need to be avoided immediately</li><br>
                                    <li class="text-justify">Examining the processes, policies and procedures for their efficacy</li><br>
                                    <li class="text-justify">Calibrating processes as per their impact on the business</li><br>
                                    <li class="text-justify">Develop a continuity aspect for the creating a resilient business scenario</li><br>
                                    <li class="text-justify">Are you still wondering how to implement a BCP/DR plan? Experts at Aries can help you perform a complete business impact analysis to come up with the best recovery solution to protect your organization in case of unforeseen events.</li><br>
                                </ul>
                          </div>
                          <div class="col-12">                              
                            <h6 style="color: #021058">Aries DR SOLUTIONS ARE CUSTOMIZED TO SUIT YOUR ORGANIZATION’S NEEDS</h6>
                                <ul>
                                    <li class="text-justify">Unless you are few of those organizations who have the resources and the expertise to have an in-house DR set up – managing an in-house DR can be a herculean task if not impossible. Managing a DR in-house comes with its own complexities both technical and procedural – minimizing downtime, controlling costs, maintaining high availability are just a few. Fortunately, Aries DR Solutions make designing, deploying and managing a DR plan less cumbersome and more affordable. Our solutions are designed to suit your specific needs and requirements.</li>
                                    <br>
                                </ul>
                          </div>
                          <div class="col-12">                              
                            <h6 style="color: #021058">OUR DR PORTFOLIO</h6>
                            <h6 style="color: #021058">Thrive under uncertain conditions</h6>
                                <ul>
                                    <li class="text-justify"><img class="img-responsive" src="img/work_area/work.png"></li>
                                    <br>
                                </ul>
                          </div>
                          <div class="col-12">                              
                            <h6 style="color: #021058">Aries DR EXPERTISE</h6>
                            <h6 style="color: #021058">Our approach to DR</h6>
                                <ul>
                                    <li class="text-justify"><img class="img-responsive" src="img/work_area/work1.png"></li>
                                    <br>
                                </ul>
                          </div>
                          <div class="col-12">                              
                            <h6 style="color: #021058">SOME COMMONLY USED TERMS IN DR & BCP</h6>
                                <ul>
                                    <li class="text-justify"><span class="text-info">Business Continuity Plan (BCP):</span> Includes planning to ensure the continuity of business critical functions in the event of a major unplanned service failure or disaster—including key aspects such as personnel, facilities, crisis communication, project management and change control. A BC strategy includes a Disaster Recovery Plan (DRP) for IT related infrastructure recovery.
                                        Disaster Recovery (DR): Part of a larger Business Continuity plan that includes processes and solutions to restore business critical applications, data, hardware, communications (such as networking) and other IT infrastructure. Can also include measures to protect against other unplanned events such as the failure of an individual server or shorter service interruptions.</li><br>
                                        
                                        <li class="text-justify"><span class="text-info">Mission-critical:</span> Systems or applications that are essential to the functioning of your business and its processes.</li><br>
                                        
                                        <li class="text-justify"><span class="text-info">Redundancy:</span> Systematically using multiple sources, devices or connections to eliminate single points of failure that could completely stop the flow of information.</li><br>
                                        
                                        <li class="text-justify"><span class="text-info">High Availability (HA):</span> A system or component that is continuously operational for a desirably long length of time.
                                        Recovery Point Objective (RPO): The age of files that must be recovered for normal operations to resume if a system goes down as a result of a failure.</li><br>
                                        
                                        <li class="text-justify"><span class="text-info">Recovery Time Objective (RTO):</span> The maximum tolerable length of time that a computer, system, network or application can be down after a failure or disaster occurs.</li><br>
                                        
                                        <li class="text-justify"><span class="text-info">Hot site:</span> A DR facility fully equipped with the equipment, network connections and environmental conditions necessary for restoring your data and getting your systems up and running instantly. (Unlike cold sites and warm sites, which are not ready to go in an instant)</li><br>
                                        
                                        <li class="text-justify"><span class="text-info">Total Cost of ownership (TCO): </span>Risk Analysis and evaluation of the total cost of ownership (TCO) of the risk mitigation approaches available.</li><br>
                                </ul>
                                
                          </div>
                        </div>
                    </div>
                    
                    <div class="col-md-3">
                        <div class="box">
                        <div class="row">
                            <h6 style="color: #021058">Need help deciding?</h6>
                            <p>CONTACT US</p>
                        </div>
                            <div class="row">
                               
                                <div class="col-3">
                                    <i class="fa fa-headphones" aria-hidden="true"></i>
                                </div>
                                <div class="col-9"> 
                                        <p><b style="color: #021058">1800-102-8757</b></p>
                                        <p>Sales Toll Free Number</p>
                                </div>
                            </div> 
                           </div>
                            
                           <!-- <div class="box mt-3">-->
                           <!--     <div id="crmWebToEntityForm" class="form-box">-->
                           <!--        <meta http-equiv="content-type" content="text/html;charset=UTF-8">-->
                           <!--     	<form action="" name="WebToLeads2569189000036821042" method="POST" onsubmit="javascript:document.charset=&quot;UTF-8&quot;; return checkMandatory2569189000036821042()" accept-charset="UTF-8" siq_id="autopick_4437">-->
                           <!--     		<input type="text" style="display:none;" name="xnQsjsdp" value="5bbf9f74877d7cbf151ef666b662b48a23ff284067d965528e240073aedb838e"> -->
                           <!--      <input type="hidden" name="zc_gad" id="zc_gad" value=""> -->
                           <!--      <input type="text" style="display:none;" name="xmIwtLD" value="32ce659de9c603b6bad36dc19a4b9268a1e34860f3aae765e5c067e4d81d605e"> -->
                           <!--      <input type="text" style="display:none;" name="actionType" value="TGVhZHM=">-->
                           <!--     <input type="text" style="display:none;" name="returnURL" value="https://www.ctrls.com/thankyou.php"> -->
                                				
                           <!--     		<h6 style="color: #021058">Sounds good?<span>Fill up the form below &amp; Get Attractive Offers</span></h6>-->
                           <!--     		<ul>-->
                           <!--     			<li>-->
                           <!--     				<label>Name<span style="color:red;">*</span></label>-->
                           <!--     				<input type="text" class="form-control" maxlength="80" name="Last Name">-->
                           <!--     			</li>-->
                           <!--     			<li>-->
                           <!--     				<label>Your email address<span style="color:red;">*</span></label>-->
                           <!--     				<input type="text" class="form-control" id="email" maxlength="100" name="Email">-->
                           <!--     			</li>-->
                           <!--     			<li>-->
                           <!--     				<label>Phone number<span style="color:red;">*</span></label>-->
                           <!--     				<input type="text" class="form-control" id="phone" maxlength="30" name="Phone">-->
                           <!--     			</li>-->
                                
                           <!--     			<li>-->
                           <!--     				<label>Comments</label>-->
                           <!--     				<textarea class="form-control" id="msg" name="Description" maxlength="32000" rows="3" style="height: 50px !important;">&nbsp;</textarea>-->
                           <!--     			</li><br>-->
                                			
                           <!--     			<li>-->
                           <!--     				<img id="imgid" src="https://crm.zoho.com/crm/CaptchaServlet?formId=32ce659de9c603b6bad36dc19a4b9268a1e34860f3aae765e5c067e4d81d605e&amp;grpid=5bbf9f74877d7cbf151ef666b662b48a23ff284067d965528e240073aedb838e"><br>-->
                                
                           <!--     				<label>Enter the code above here :</label><br>-->
                                
                           <!--     				<input type="text" class="form-control" maxlength="80" name="enterdigest"><br>-->
                           <!--     				<small>Can't read the image? click <a href="javascript:;" onclick="reloadImg()">here</a> to refresh</small>-->
                                				
                           <!--     			</li>-->
                           <!--     			<li style="display:none;">-->
                           <!--     				<label>Lead Source</label>-->
                           <!--     				<select name="Lead Source">-->
                           <!--     					<option value="-None-">-None-</option>-->
                           <!--     					<option value="Cloud4C Google Ads">Cloud4C Google Ads</option>-->
                           <!--     					<option value="CtrlS.com">CtrlS.com</option>-->
                           <!--     					<option value="Cloud4C.com Google Adwords">Cloud4C.com Google Adwords</option>-->
                           <!--     					<option value="Cloud4c.com LivServ">Cloud4c.com LivServ</option>-->
                           <!--     					<option value="Cloud4C.com SalesIQ Chat">Cloud4C.com SalesIQ Chat</option>-->
                           <!--     					<option value="Cloud4C.com Website">Cloud4C.com Website</option>-->
                           <!--     					<option value="Colocation-ctrlS.com">Colocation-ctrlS.com</option>-->
                           <!--     					<option value="Colocation-ctrlS.com - Chat">Colocation-ctrlS.com - Chat</option>-->
                           <!--     					<option value="CtrlS Google Ads">CtrlS Google Ads</option>-->
                           <!--     					<option value="CtrlS.com - Data Center">CtrlS.com - Data Center</option>-->
                           <!--     					<option value="CtrlS.com - Data Center - Chat">CtrlS.com - Data Center - Chat</option>-->
                           <!--     					<option value="CtrlS.com Google Adwords">CtrlS.com Google Adwords</option>-->
                           <!--     					<option value="CtrlS.com SalesIQ Chat">CtrlS.com SalesIQ Chat</option>-->
                           <!--     					<option selected="" value="CtrlS.com Website">CtrlS.com Website</option>-->
                           <!--     					<option value="Ctrls.in Chat">Ctrls.in Chat</option>-->
                           <!--     					<option value="CtrlS.in SalesIQ Chat">CtrlS.in SalesIQ Chat</option>-->
                           <!--     					<option value="CtrlS.in Website">CtrlS.in Website</option>-->
                           <!--     					<option value="Downloads Cloud4C">Downloads Cloud4C</option>-->
                           <!--     					<option value="Downloads CtrlS">Downloads CtrlS</option>-->
                           <!--     					<option value="Email Marketing">Email Marketing</option>-->
                           <!--     					<option value="Form Fills Cloud4C">Form Fills Cloud4C</option>-->
                           <!--     					<option value="Form Fills CtrlS">Form Fills CtrlS</option>-->
                           <!--     					<option value="Human Resource">Human Resource</option>-->
                           <!--     					<option value="Linkedin">Linkedin</option>-->
                           <!--     					<option value="Managed services - Facebook">Managed services - Facebook</option>-->
                           <!--     					<option value="Managed services - Google">Managed services - Google</option>-->
                           <!--     					<option value="Marketing Cloud4C">Marketing Cloud4C</option>-->
                           <!--     					<option value="Marketing CtrlS">Marketing CtrlS</option>-->
                           <!--     					<option value="Publishers">Publishers</option>-->
                           <!--     					<option value="Referrals">Referrals</option>-->
                           <!--     					<option value="Registration">Registration</option>-->
                           <!--     					<option value="Toll Free Cloud4C">Toll Free Cloud4C</option>-->
                           <!--     					<option value="Toll Free CtrlS">Toll Free CtrlS</option>-->
                           <!--     				</select>-->
                           <!--     			</li>-->
                           <!--     			<li style="display:none;">-->
                           <!--     				<label>Page URL</label>-->
                           <!--     				<textarea id="pageUrl" name="LEADCF2" maxlength="2000"></textarea>-->
                           <!--     			</li>-->
                           <!--     			<li style="display:none;">-->
                           <!--     				<label>Paid Identifier</label>-->
                           <!--     				<select name="LEADCF14">-->
                           <!--     					<option value="-None-">-None-</option>-->
                           <!--     					<option value="Paid">Paid</option>-->
                           <!--     					<option selected="" value="Non Paid">Non Paid</option>-->
                           <!--     				</select>-->
                           <!--     			</li>-->
                           <!--     			<li>-->
                           <!--     				<input class="btn btn-success btn-block" style="color:#FFF; background:#090; font-size:15px;" id="formsubmit" type="submit" value="Submit">-->
                           <!--     			</li><br>-->
                           <!--     		</ul>-->
                                		
                           <!--     		<script>-->
                           <!--     			var newUrl = window.location.href;-->
                           <!--     			console.log('Page Url:', newUrl);-->
                                
                           <!--     			$(document).ready(function(){-->
                           <!--     				$('#pageUrl').val(newUrl);-->
                           <!--     			})-->
                                			
                           <!--     			function isEmail(email) {-->
                           <!--     				var pattern = new RegExp(/^((([a-z]|\d|[!#\$%&'\*\+\-\/=\?\^_`{\|}~]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])+(\.([a-z]|\d|[!#\$%&'\*\+\-\/=\?\^_`{\|}~]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])+)*)|((\x22)((((\x20|\x09)*(\x0d\x0a))?(\x20|\x09)+)?(([\x01-\x08\x0b\x0c\x0e-\x1f\x7f]|\x21|[\x23-\x5b]|[\x5d-\x7e]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(\\([\x01-\x09\x0b\x0c\x0d-\x7f]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]))))*(((\x20|\x09)*(\x0d\x0a))?(\x20|\x09)+)?(\x22)))@((([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.)+(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.?$/i);-->
                           <!--     				if (pattern.test(email)) {-->
                           <!--     					return true;-->
                           <!--     				}-->
                           <!--     				return false;-->
                           <!--     			}-->
                                
                           <!--     			var mndFileds=new Array('Last Name','Email','Phone', 'enterdigest');-->
                           <!--     			var fldLangVal=new Array('Name','Email address','Phone number', 'Captcha');-->
                           <!--     			var name='';-->
                           <!--     			var email='';-->
                                			
                                			<!--/* Do not remove this code. */-->
                           <!--     			function reloadImg() {-->
                           <!--     				if(document.getElementById('imgid').src.indexOf('&d') !== -1 ) {-->
                           <!--     					document.getElementById('imgid').src=document.getElementById('imgid').src.substring(0,document.getElementById('imgid').src.indexOf('&d'))+'&d'+new Date().getTime();-->
                           <!--     				}  else {-->
                           <!--     					document.getElementById('imgid').src = document.getElementById('imgid').src+'&d'+new Date().getTime();-->
                           <!--     				} -->
                           <!--     			}-->
                           <!--     			function isPhone(phone) {-->
                           <!--     				if (!$.isNumeric(phone)) {-->
                           <!--     					return false;-->
                           <!--     				}-->
                           <!--     				if (phone.length < 10 || phone.length > 15) {-->
                           <!--     					return false;-->
                           <!--     				}-->
                           <!--     				return true;-->
                           <!--     			}-->
                                
                           <!--     			function checkMandatory2569189000036821042() {-->
                           <!--     				for(i=0;i<mndFileds.length;i++) {-->
                           <!--     					var fieldObj=document.forms['WebToLeads2569189000036821042'][mndFileds[i]];-->
                           <!--     					if(fieldObj) {-->
                           <!--     						if (((fieldObj.value).replace(/^\s+|\s+$/g, '')).length==0) {-->
                           <!--     							if(fieldObj.type =='file') { -->
                           <!--     								alert('Please select a file to upload.');-->
                           <!--     								fieldObj.focus();-->
                           <!--     								return false;-->
                           <!--     							}-->
                                							
                           <!--     							alert(fldLangVal[i] +' cannot be empty.');-->
                           <!--     							fieldObj.focus();-->
                           <!--     							return false;-->
                           <!--     						}  else if(fieldObj.nodeName=='SELECT') {-->
                           <!--     							if(fieldObj.options[fieldObj.selectedIndex].value=='-None-') {-->
                           <!--     								alert(fldLangVal[i] +' cannot be none.');-->
                           <!--     								fieldObj.focus();-->
                           <!--     								return false;-->
                           <!--     							}-->
                           <!--     						} else if(fieldObj.type =='checkbox'){-->
                           <!--     							if(fieldObj.checked == false){-->
                           <!--     								alert('Please accept  '+fldLangVal[i]);-->
                           <!--     								fieldObj.focus();-->
                           <!--     								return false;-->
                           <!--     							}-->
                           <!--     						} else if (fieldObj.name === "Email") {-->
                           <!--     							if (!isEmail(fieldObj.value)) {-->
                           <!--     								$("#email").focus();-->
                           <!--     								alert("Please enter valid email address");-->
                           <!--     								return false;-->
                           <!--     							}-->
                           <!--     						} else if (fieldObj.name === "Phone") {-->
                           <!--     							if (!isPhone(fieldObj.value)) {-->
                           <!--     								alert("Please enter a valid Phone Number");-->
                           <!--     								$("#phone").focus();-->
                           <!--     								return false;-->
                           <!--     							}-->
                           <!--     						} try {-->
                           <!--     							if(fieldObj.name == 'Last Name') {-->
                           <!--     								name = fieldObj.value;-->
                           <!--     							}-->
                           <!--     						} catch (e) {-->
                                
                           <!--     						}-->
                           <!--     					}-->
                           <!--     				}-->
                           <!--     				document.getElementById('formsubmit').disabled=true;-->
                           <!--     			}-->
                                			
                           <!--     		</script>-->
                           <!--     	</form>-->
                                	
                                	<!-- Do not remove this code. -->
                           <!--     	<iframe name="captchaFrame" style="display:none;" __idm_frm__="70"></iframe>-->
                           <!--     </div>-->
                           <!--</div>-->
                           
                            <div class="box mt-3">
                        <div class="row">
                            <h6 style="color: #021058">Sounds good?</h6>
                            <p>FILL UP THE FORM BELOW & GET ATTRACTIVE OFFERS</p>
                        </div>
                            <div class="row">
                               
                                <div class="col-12">
                                    <form action="/action_page.php">
                                         <div class="form-group">
                                        <label for="name">Name</label>
                                        <input type="name" class="form-control" id="name">
                                      </div>
                                      <div class="form-group">
                                        <label for="email"> Your Email address</label>
                                        <input type="email" class="form-control" id="email">
                                      </div>
                                      <div class="form-group">
                                        <label for="pwd">Phone Number</label>
                                        <input type="password" class="form-control" id="pwd">
                                      </div>
                                       <div class="form-group">
                                        <label for="pwd">Comments</label>
                                        <textarea type="password" class="form-control" id="pwd"></textarea>
                                      </div>
                                      <button type="submit" class="btn btn-primary btn-sm mb-4">Submit</button>
                                    </form>
                                </div>
                                
                            </div> 

                           </div>
                            
                            <div class="box mt-3">
                        
                            <div class="row">
                               
                                <div class="col-12">
                                     
                                    <div id="myCarousel" class="carousel slide" data-ride="carousel">
                                        <h6 style="color: #021058">Testimonials</h6> 
                                <!-- Carousel indicators -->
                                 
                                <!-- Wrapper for carousel items -->
                                <div class="carousel-inner">  
                                    
                                    <div class="item carousel-item active">
                                        
                                        <p class="testimonial">Aries maintains good relationships and follows up regularly about the service, to ensure that everything goes smoothly.</p>
                                        <h6>Mr.Manoj Patel</h6>
                                             <p>Relay Express</p>
                                    </div>


                                    <div class="item carousel-item">
                                        
                                        <p class="testimonial">Migration to Cloud was made so easy by CtrlS.Server was installed and set up without any problems, most importantly, zero downtime.
                                       </p>
                                       <h6>Mr.NVV Krishnam Raju</h6>
                                             <p>Seventeen Networks</p>
                                        
                                    </div>
                                        
                                                                    </div>
                                        <!-- Carousel controls -->
                                        <a class="carousel-control left carousel-control-prev" href="#myCarousel" data-slide="prev">
                                            <i class="fa fa-angle-left"></i>
                                        </a>
                                        <a class="carousel-control right carousel-control-next" href="#myCarousel" data-slide="next">
                                            <i class="fa fa-angle-right"></i>
                                        </a>
                                    </div>
                                </div>
                               
                            </div> 
                           </div> 
                        </div> 
                        </div>

                    </div>
                 </div>

            </div>

        </div>
    </div>
    <!-- #####  ##### -->
  <!-- ##### Partner Area Start ##### -->
    <div class="partner-area pt-5 pb-5">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <h6 style="color: #021058">A FEW OF OUR MORE RECOGNIZABLE CLIENTS</h6>
                    <div class="partners-logo d-flex align-items-center justify-content-between  mt-5">
                        <a href="#"><img src="img/clients-img/partner-1.png" alt=""></a>
                        <a href="#"><img src="img/clients-img/partner-2.png" alt=""></a>
                        <a href="#"><img src="img/clients-img/partner-3.png" alt=""></a>
                        <a href="#"><img src="img/clients-img/partner-4.png" alt=""></a>
                        <a href="#"><img src="img/clients-img/partner-5.png" alt=""></a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- ##### Partner Area End ##### -->
   

    <!-- ##### Footer Area Start ##### -->
   <?php include('include/footer.php'); ?>
    <!-- ##### Footer Area Start ##### -->

    <!-- ##### All Javascript Script ##### -->
    <!-- jQuery-2.2.4 js -->
    <script src="js/jquery/jquery-2.2.4.min.js"></script>
    <!-- Popper js -->
    <script src="js/bootstrap/popper.min.js"></script>
    <!-- Bootstrap js -->
    <script src="js/bootstrap/bootstrap.min.js"></script>
    <!-- All Plugins js -->
    <script src="js/plugins/plugins.js"></script>
    <!-- Active js -->
    <script src="js/active.js"></script>
</body>

</html>