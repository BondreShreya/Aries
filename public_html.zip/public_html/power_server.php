<!DOCTYPE html>
<html lang="en">

 <?php include('include/head.php'); ?>
 <style>
 .holder
 {
    overflow: hidden;
    margin: 0 0 0 -2px;
 }
 .column
 {
    float: left;
    width: 324px;
    padding: 0 23px 0 0;
 }
 .img
 {
    float: left;
    width: 121px;
    height: 430px;
    margin: 0 21px 0 0;
    overflow: hidden;
 }
 .reasons ul
 {
    list-style: none;
    margin: 0;
    padding: 35px 0 0;
    overflow: hidden;
    color: #555;
    font-size: 14px;
    font-weight: bold;
 }
 .item-01
    {
        min-height: 140px;
    }
    .item-01
    {
        line-height: 20px;
        padding: 0 0 10px;
    }
    .item-02
    {
    min-height: 155px;
    }
    .item-02
    {
    line-height: 20px;
    padding: 0 0 10px;
    }
    .item-03
    {
    min-height: 100px;
    }
    .item-03
    {
    line-height: 20px;
    padding: 0 0 10px;
    }
    .item-04
    {
    min-height: 152px;
    padding: 6px 0 10px;
    }
    .item-04
    {
        line-height: 20px;
    }
    .item-05
    {
    min-height: 144px;
    }
    .item-05
    {
    line-height: 20px;
    padding: 0 0 10px;
    }
    #content .resons ul .item-06
    {
    min-height: 50px;
    }
    .item-06
    {
    line-height: 20px;
    padding: 0 0 10px;
    }
    .color-box {
    margin: 0 0 39px 2px;
    background: #e9f6fc;
    overflow: hidden;
    border: solid 1px #d6e9f2;
    color: #666;
    font-weight: bold;
    position: relative;
    -webkit-border-radius: 6px;
    -moz-border-radius: 6px;
    border-radius: 6px;
    padding: 13px 10px;
    line-height: 35px;
    font: bold 13px/29px Lucida Sans Unicode, Lucida Grande, sans-serif;
}
.btn-select {
    float: right;
    border: solid 1px #0886c1;
    background: rgb(0,173,255);
    background: -moz-linear-gradient(top, rgba(0,173,255,1) 0%, rgba(11,152,218,1) 100%);
    background: -webkit-gradient(linear, left top, left bottom, color-stop(0%, rgba(0,173,255,1)), color-stop(100%, rgba(11,152,218,1)));
    background: -webkit-linear-gradient(top, rgba(0,173,255,1) 0%, rgba(11,152,218,1) 100%);
    background: -o-linear-gradient(top, rgba(0,173,255,1) 0%, rgba(11,152,218,1) 100%);
    background: -ms-linear-gradient(top, rgba(0,173,255,1) 0%, rgba(11,152,218,1) 100%);
    background: linear-gradient(to bottom, rgba(0,173,255,1) 0%, rgba(11,152,218,1) 100%);
    filter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#00adff', endColorstr='#0b98da', GradientType=0 );
    -pie-background: linear-gradient(top, rgba(0,173,255,1) 0%, rgba(11,152,218,1) 100%);
    position: relative;
    height: 35px;
    padding: 0 10px;
    color: #feffff;
    font: 14px/35px 'lucidasansdemibold', sans-serif;
    text-transform: uppercase;
}
 .color-box a
 {
    color: #FFF;
}
.color-box p
{
    overflow: hidden;
    margin:0;
}
.list
{
padding: 0 0 28px 4px;
margin: 0 0 17px;
}
.folder
{
overflow: hidden;
margin: 0 0 0 -60px;
}
.list ol
{
line-height: 18px;
    padding: 0 0 12px 28px;
    /*background: url(../images/bullet-14.gif) no-repeat 0 2px;*/
}
.list ol {
    float: left;
    width: 314px;
    list-style: none;
    margin: 0;
    padding: 0 0 0 61px;
    font-size: 14px;
    color: #666;
}
</style>
<script src="https://kit.fontawesome.com/a076d05399.js"></script>
<body>
    <!-- ##### Preloader ##### -->
    <!-- <div id="preloader">
        <i class="circle-preloader"></i>
    </div> -->

    <!-- ##### Header Area Start ##### -->
   <?php include('include/header.php'); ?>
    <!-- ##### Header Area End ##### -->

    <!-- ##### Hero Area Start ##### -->

    <section>
   
      

            <!-- Single Hero Slide -->

            <div class="single-hero-slide1 mt-4 bg2-img">
 
                <div class="container h-100">
                    <div class="row h-100 align-items-center">
                        <div class="col-12">
                            <div class="hero-slides-content">
                            <h3 class="text-dark heading pb-2">Power Application Servers</h3>
                            <p class="text-justify mt-4">Get the reliability of running your workloads on our latest generation and branded<br>
                            dedicated servers which meet the most demanding IO and compute intensive workloads.<br>

                            Our promise of highest uptime, Superfast connectivity & lowest latency in our Tier 4 datacenters will ensure<br> that your applications are always on so will be your business.</p>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Single Hero Slide -->

      
    </section>
    <!-- ##### Hero Area End ##### -->
    <section>
        <nav aria-label="breadcrumb">
          <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="index.php">Home</a></li>
            <li class="breadcrumb-item active" aria-current="page"><a href="colocation.php">Dedicated Server</a></li>
            <li class="breadcrumb-item">Power Server</li>
          </ol>
        </nav>
    </section>
   

    <!-- ##### ##### -->
    <div class="partner-area pt-5">
        <div class="container">
                 <div class="row">
                    <div class="col-md-9">
                       
                       
                        <div class="row">
                            <div class="col-md-12">
                            <h4 style="color: #021058">POWER SERVERS PACKAGES</h4>
                            </div>
                        </div>
                        <!-- table -->
                            <table class="table table-responsive table-bordered">
                              <thead>
                                <tr>
                                    <th></th>
                                  <th>DSP 1</th>
                                  <th> DSP 2</th>
                                  <th> DSP 3</th>
                                  <th> DSP 4</th>
                                </tr>
                              </thead>
                              <tbody>
                                <tr>
                                   <th style="color: #6fc572">Processor</th>
                                   <td>Hexa core E5-2620 v3</td>
                                   <td>Hexa core E5-2630 v3</td>
                                   <td>2 X Hexa core E5 2620 v3</td>
                                   <td>2 X Octa core E5 2640 v3</td>
                                </tr>
                                <tr>
                                   <th style="color: #6fc572">Memory</th>
                                   <td>16 GB</td>
                                   <td>24 GB</td>
                                   <td>32 GB</td>
                                   <td>64 GB</td>
                                 </tr>
                                <tr>
                                  <th style="color: #6fc572">Disk space
                                   </th>
                                   <td>2 X 2 TB SATA</td>
                                   <td>3 X 900 GB SAS</td>
                                   <td>4 X 900 GB SAS</td>
                                   <td>4 X 900 GB SAS</td>
                                </tr>
                                <tr>
                                    <th style="color: #6fc572">Bandwidth</th>
                                   <td>250 GB</td>
                                   <td>250 GB</td>
                                   <td>250 GB</td>
                                   <td>250 GB</td>
                                </tr>
                                <tr>
                                   <th style="color: #6fc572">IP addresses</th>
                                   <td>2</td>
                                   <td>2</td>
                                   <td>2</td>
                                   <td>2</td>
                                 </tr>
                                 <tr>
                                   <th style="color: #6fc572">Choice of OS </th>
                                   <td>
                                    <input type="radio" value="4110(Linux)" name="radio" checked="checked">
                                    <img src="img\linux.png" title="Linux LOGO" align="absmiddle">
                                    <input type="radio" value="4700(Windows)">
                                    <img src="img\windows.png" title="Cloud OS" align="absmiddle">
                                    </td>
                                   <td>
                                    <input type="radio" value="4110(Linux)" name="radio" checked="checked">
                                    <img src="img\linux.png" title="Linux LOGO" align="absmiddle">
                                    <input type="radio" value="4700(Windows)">
                                    <img src="img\windows.png" title="Cloud OS" align="absmiddle">
                                   </td>
                                   <td>
                                    <input type="radio" value="4110(Linux)" name="radio" checked="checked">
                                    <img src="img\linux.png" title="Linux LOGO" align="absmiddle">
                                    <input type="radio" value="4700(Windows)">
                                    <img src="img\windows.png" title="Cloud OS" align="absmiddle">
                                   </td>
                                   <td><input type="radio" value="4110(Linux)" name="radio" checked="checked">
                                    <img src="img\linux.png" title="Linux LOGO" align="absmiddle">
                                    <input type="radio" value="4700(Windows)">
                                    <img src="img\windows.png" title="Cloud OS" align="absmiddle">
                                   </td>
                                 </tr>
                                 <tr>
                                    <td></td>
                                 <td>
                                    <a class="fancybox btn-buy" href="#inline1" data-toggle="modal" data-target="#enquiry" style="border-radius: 5px; background: #4AB54D; color: #fff9f9; text-decoration: none; padding: 4px;"><span>BUY & DEPLOY</span></a>
                                   </td>
                                   <td>
                                    <a class="fancybox btn-buy" href="#inline1" data-toggle="modal" data-target="#enquiry" style="border-radius: 5px; background: #4AB54D; color: #fff9f9; text-decoration: none; padding: 4px;"><span>BUY & DEPLOY</span></a>
                                   </td>
                                   <td>
                                    <a class="fancybox btn-buy" href="#inline1" data-toggle="modal" data-target="#enquiry" style="border-radius: 5px; background: #4AB54D; color: #fff9f9; text-decoration: none; padding: 4px;"><span>BUY & DEPLOY</span></a>
                                   </td>
                                   <td>
                                    <a class="fancybox btn-buy" href="#inline1" data-toggle="modal" data-target="#enquiry" style="border-radius: 5px; background: #4AB54D; color: #fff9f9; text-decoration: none; padding: 4px;"><span>BUY & DEPLOY</span></a>
                                   </td>
                                 </tr>
                              </tbody>
                            </table>
                        <!-- //table -->
                        <div class="row">
                            <div class="col-md-5">
                                <p style="border-right: 1px dotted">Click to explore our other service offering</p>
                            </div>
                            <div class="col-md-3">
                                <p style="border-right: 1px dotted"><a href="#">Cloud Server</a></p>
                            </div>
                            <div class="col-md-4">
                                <p><a href="#">US Server</a></p>
                            </div>
                        </div>
                        <h4 style="color: #021058">ABOUT OUR SERVERS</h4>
                        <p>Our Dedicated servers are extremely reliable and are built to give you the highest level of uptime and performance. They can cater to diverse workloads and complex computing requirements. In case of of standard websites, web apps and databases which require low to mid IO our Single processor Value dedicated servers can get you up and running. To run applications which gets high traffic and needs to handle intensive database workloads our dedicated power servers would be the right fit.</p>
                        <p>Choose the pre-configured specification of your choice and get your server up and running within hour. and you can choose to pay monthly, quarterly, semi-annually or annually (ensuring maximum saving).</p>
                        <p>You can also bundle the servers with advanced add-on’s like managed services, monitoring, security, load balancing, backup, etc. or create a customized high availability solution using our dedicated server stack to get better redundancy and uptime.</p>
                        <div class="reasons">
                            <h4 style="color: #021058">6 REASONS YOU’LL LOVE OUR SERVERS</h4>
                            <div class="holder">
                                <div class="column">
                                    <div class="img">
                                        <img src="img/server/power-servers.png" class="img-fluid">
                                    </div>
                                    <!-- end img -->
                                    <ul>
                                        <li class="item-01">24X7 Telephone Support</li>
                                        <li class="item-02">Free Disk Mirroring with Hardware RAID</li>
                                        <li class="item-03">Perimeter Level Firewall</li>
                                    </ul>
                                </div>
                            <!-- end column -->
                            <div class="column">
                                <div class="img">
                                    <img src="img/server/dedicated-power-servers.png" class="img-fluid">
                                </div>
                                <!-- end img -->
                                <ul>
                                    <li class="item-04">Branded Server with RPS</li>
                                    <li class="item-05">Migration Assistance</li>
                                    <li class="item-06">Personal Relationship Manager</li>
                                </ul>
                            </div>
                            <!-- end colunm -->
                        </div>
                        <!-- end holder -->
                    </div>
                    <!-- end reasons -->

                        <div class="color-box" style="border: solid 1px #4CAF50;">
                            <a style="margin-top: 0px;    background: #4ab54d;" href="#plans-block" class="btn-select" title="Select a Plan">select a plan</a>
                            <p style=" padding-top: 5px; ">Plenty of reasons to get started. Just pick a plan and we’ll do the rest!</p>
                        </div>
                        <!-- end color box -->
                        <div class="list" style="background:none">
                            <h4 style="color: #021058">INCLUDED WITH ALL PLANS</h4>
                            <div class="folder">
                                <ol>
                                    <li>Full Root Level Access RDP desktop or Putty</li>
                                    <li>Unlimited Remote Hands support</li>
                                    <li>Perimeter level firewall, spam &amp; antivirus</li>
                                    <li>Peace of mind 99.995% high availability SLA</li>
                                </ol>
                                <ol>
                                    <li>100 Mbps Burstable bandwidth on a carrier neutral network</li>
                                    <li>Bandwidth usage with MRTG Graphs</li>
                                    <li>24 X 7 Direct Phone Support</li>
                                </ol>
                            </div>
                        </div>
                </div>
                    <div class="col-md-3">
                        <!--<div class="box">-->
                        <!--<div class="row">-->
                        <!--    <h6 style="color: #021058">Need help deciding?</h6>-->
                        <!--    <p>CONTACT US</p>-->
                        <!--</div>-->
                        <!--    <div class="row">-->
                               
                        <!--        <div class="col-3">-->
                        <!--            <i class="fa fa-headphones" aria-hidden="true"></i>-->
                        <!--        </div>-->
                        <!--        <div class="col-9">-->
                        <!--                <p><b style="color: #021058">1800-102-8757</b></p>-->
                        <!--                <p>Sales Toll Free Number</p>-->
                        <!--        </div>-->
                        <!--    </div>-->
                        <!--   </div>-->
                        <div class="box mt-3">
                        <div class="row">
                            <h6 style="color: #021058">Sounds good?</h6>
                            <p>FILL UP THE FORM BELOW & GET ATTRACTIVE OFFERS</p>
                        </div>
                            <div class="row">
                               
                                <div class="col-12">
                                    <form action="/action_page.php">
                                         <div class="form-group">
                                        <label for="name">Name</label>
                                        <input type="name" class="form-control" id="name">
                                      </div>
                                      <div class="form-group">
                                        <label for="email"> Your Email address</label>
                                        <input type="email" class="form-control" id="email">
                                      </div>
                                      <div class="form-group">
                                        <label for="pwd">Phone Number</label>
                                        <input type="password" class="form-control" id="pwd">
                                      </div>
                                       <div class="form-group">
                                        <label for="pwd">Comments</label>
                                        <textarea type="password" class="form-control" id="pwd"></textarea>
                                      </div>
                                      <button type="submit" class="btn btn-primary btn-sm mb-4">Submit</button>
                                    </form>
                                </div>
                               
                            </div>
                           </div>  

                           <div class="box mt-3">
                        <div class="row">
                            <h6 style="color: #021058">Other Category Products</h6>
                        </div>
                            <div class="row">
                                <div class="col-12" style="height: 357px;">
                                    <ul class="list-group">
                                        <li class="list-group-item"><a href="windows-vps.php" target="_blank">Windows VPS</a>
                                        <span>Windows based Virtual Private Servers</span></li>
                                      <li class="list-group-item"><a href="managed-vps.php" target="_blank">Managed VPS</a><span>VPS with L1, L2 and L3 Managed Services</span></li>
                                      <li class="list-group-item"><a href="managed-vps.php" target="_blank">Managed VPS</a><span>VPS with L1, L2 and L3 Managed Services</span></li>
                                      <li class="list-group-item"><a href="hosters-vps.php" target="_blank">Hosters VPS</a><span>VPS with Control Panels</span></li>
                                    </ul>
                                </div>
                               
                            </div>
                           </div>
                       <div class="box mt-3">
                       
                            <div class="row">
                               
                                <div class="col-12">
                                     
                                    <div id="myCarousel" class="carousel slide" data-ride="carousel">
                                        <h6 style="color: #021058">Testimonials</h6>
                                <!-- Carousel indicators -->
                                 
                                <!-- Wrapper for carousel items -->
                                <div class="carousel-inner">  
                                   
                                    <div class="item carousel-item active">
                                       
                                        <p class="testimonial">Aries maintains good relationships and follows up regularly about the service, to ensure that everything goes smoothly.</p>
                                        <h6>Mr.Manoj Patel</h6>
                                             <p>Relay Express</p>
                                    </div>


                                    <div class="item carousel-item">
                                       
                                        <p class="testimonial">Migration to Cloud was made so easy by CtrlS.Server was installed and set up without any problems, most importantly, zero downtime.
                                       </p>
                                       <h6>Mr.NVV Krishnam Raju</h6>
                                             <p>Seventeen Networks</p>
                                       
                                    </div>
                                       
                                                                    </div>
                                        <!-- Carousel controls -->
                                        <a class="carousel-control left carousel-control-prev" href="#myCarousel" data-slide="prev">
                                            <i class="fa fa-angle-left"></i>
                                        </a>
                                        <a class="carousel-control right carousel-control-next" href="#myCarousel" data-slide="next">
                                            <i class="fa fa-angle-right"></i>
                                        </a>
                                    </div>
                                </div>
                               
                            </div>
                           </div>
                        </div>

                    </div>
                 </div>

            </div>

        </div>
    </div>
    <!-- #####  ##### -->
   

    <!-- ##### Footer Area Start ##### -->
   <?php include('include/footer.php'); ?>
    <!-- ##### Footer Area Start ##### -->

    <!-- ##### All Javascript Script ##### -->
    <!-- jQuery-2.2.4 js -->
    <script src="js/jquery/jquery-2.2.4.min.js"></script>
    <!-- Popper js -->
    <script src="js/bootstrap/popper.min.js"></script>
    <!-- Bootstrap js -->
    <script src="js/bootstrap/bootstrap.min.js"></script>
    <!-- All Plugins js -->
    <script src="js/plugins/plugins.js"></script>
    <!-- Active js -->
    <script src="js/active.js"></script>
</body>

</html>