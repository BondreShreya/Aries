 <header class="header-area">

        <!-- Top Header Area -->
      <!--   <div class="top-header">
            <div class="container h-100">
                <div class="row h-100">
                    <div class="col-12 h-100">
                        <div class="header-content h-100 d-flex align-items-center justify-content-between">
                            <div class="academy-logo mt-4">
                                <a href="index"><img src="img/core-img/Aries png-01.png" alt="" style="height:115px;width: 200px";></a>
                            </div>
                            <div class="login-content">
                                <a href="#" style="color:#021058">Register / Login</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div> -->

        <!-- Navbar Area -->
        <div class="academy-main-menu">
            <div class="classy-nav-container breakpoint-off" style="border-bottom: 3px solid #021058;">
                <div class="container-fluid">
                    <div class="row">
                    <div class="col-2">
                      <div class="academy-logo text-center">
                        <a href="index"><img src="img/core-img/Aries logo design -01" alt="" style="height:50px;width:100px";></a>
                        <h3 class="mb-0" style="color:#021058">Aries</h3>
                        <p class="">Will Beyond Reach</p>
                      </div>
                  </div>

                    <!-- Menu -->
                    <div class="col-10 p-0">
                    <nav class="classy-navbar justify-content-between" id="academyNav">

                        <!-- Navbar Toggler -->
                        <div class="classy-navbar-toggler">
                            <span class="navbarToggler"><span></span><span></span><span></span></span>
                        </div>

                        <!-- Menu -->
                        <div class="classy-menu">

                            <!-- close btn -->
                            <div class="classycloseIcon">
                                <div class="cross-wrap"><span class="top"></span><span class="bottom"></span></div>
                            </div>
                          
                            <!-- Nav Start -->
                            <div class="classynav p-0">
                                 
                                <ul class="" style="border: 1px solid #021058;padding: 10px"> 
                                    <li style="border-right:2px solid grey">
                                       
                                        <a href="index"><img src="img/png/home1.png"></a>
                                        
                                    </li>
                                    <li style="border-right:2px solid grey" class="">
                                       
                                        <a href="cloud-server">CLOUD SERVER</a>
                                         <ul class="dropdown">
                                            <li><a href="enterprise_cloud">Enterprise Cloud</a></li>
                                            <li><a href="cloud_saas_apps">Cloud SaaS & Apps</a></li>
                                            <li><a href="cloud_with_load_balancer">Cloud with load balancer dedicated firewall and clustering</a></li>
                                            <li><a href="cloud_cdn">Cloud CDN</a></li>
                                            <li><a href="white_labelled_cloud">White labelled Cloud</a></li>
                                            <li><a href="cloud_comparision">Cloud Comparison</a></li>
                                        </ul>
                                    </li>
                                    <li style="border-right:2px solid grey" class="">
                                        <a href="dedicated-server">DEDICATED SERVER</a>
                                        <ul class="dropdown">
                                           <li><a href="power_server">Power Servers</a></li>
                                            <li><a href="value_server">Value Servers</a></li>
                                            <li><a href="us_server">US Servers</a></li>
                                            <li><a href="load-balancer">Load Balancer, Cluster and Firewall</a></li>
                                        </ul>
                                    </li>
                                    <li style="border-right:2px solid grey" class="">
                                        <a href="colocation">COLOCATION</a>
                                        <ul class="dropdown">
                                            <li><a href="server-colocation">Server Colocation</a></li>
                                            <li><a href="rack-space">Rack Space</a></li>
                                            <li><a href="high-density-colocation">High Density Colocation</a></li>
                                        </ul>
                                    </li>
                                    <li style="border-right:2px solid grey" class="">
                                        <a href="business">BUSINESS SOLUTION</a>
                                        <ul class="dropdown">
                                            <li><a href="hosted_exchange">Hosted Exchange & Zimbra</a></li>
                                            <li><a href="disaster_recovery">Disaster Recovery</a></li>
                                            <li><a href="work_area_recovery">Work area Recovery (BCP Seats)</a></li>
                                            <li><a href="hosted_dynamics">Hosted Dynamics, Navision and Sharepoint</a></li>
                                            <li><a href="desktop_service">Desktop as a Service</a></li>
                                            <li><a href="application_monitoring">Application Monitoring & Performance</a></li>
                                             <li><a href="ssl_certificates">SSL Certificates</a></li>
                                        </ul>
                                    </li>
                                     <li class="mr-3">
                                        <a href="about-us">ABOUT US</a>
                                        <ul class="dropdown">
                                            <!--<li><a href="leadership_team.php">Leadership Team</a></li>-->
                                            <!--<li><a href="">Certifications</a></li>-->
                                            <!--<li><a href="">Aries Insights</a></li>-->
                                            <!--<li><a href="">Clients</a></li>-->
                                            <!--<li><a href="why_aries.php">Why Aries?</a></li>-->
                                            <!--<li><a href="">Life at CtrlS</a></li>-->
                                            <!--<li><a href="">Contact Us</a></li>-->
                                            <li><a href="career">Careers</a></li>
                                        </ul>
                                     </li>
                                </ul>
                            </div>
                            <!-- Nav End -->
                        </div>

                        <!-- Calling Info -->
                        <!-- <div class="calling-info">
                            <div class="call-center">
                                <a href="tel:+654563325568889"><i class="icon-telephone-2"></i> <span>(+65) 456 332 5568 889</span></a>
                            </div>
                        </div> -->
                    </nav>
                </div>
                </div>
                </div>
            </div>
        </div>
    </header>