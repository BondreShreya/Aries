 <header class="header-area">

        <!-- Top Header Area -->
        <div class="top-header">
            <div class="container h-100">
                <div class="row h-100">
                    <div class="col-12 h-100">
                        <div class="header-content h-100 d-flex align-items-center justify-content-between">
                            <div class="academy-logo">
                                <a href="index.php"><img src="img/core-img/Aries png-01.png" alt="" style="height: 80px;width: 100px";></a>
                            </div>
                            <div class="login-content">
                                <a href="#">Register / Login</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Navbar Area -->
        <div class="academy-main-menu">
            <div class="classy-nav-container breakpoint-off">
                <div class="container">
                    <!-- Menu -->
                    <nav class="classy-navbar justify-content-between" id="academyNav">

                        <!-- Navbar Toggler -->
                        <div class="classy-navbar-toggler">
                            <span class="navbarToggler"><span></span><span></span><span></span></span>
                        </div>

                        <!-- Menu -->
                        <div class="classy-menu">

                            <!-- close btn -->
                            <div class="classycloseIcon">
                                <div class="cross-wrap"><span class="top"></span><span class="bottom"></span></div>
                            </div>

                            <!-- Nav Start -->
                            <div class="classynav">
                                <ul>
                                    <li style="border-right:2px solid grey">
                                        <a href="cloud-server.php">CLOUD SERVER</a>
                                         <ul class="dropdown">
                                            <li style="font-size:8px"><a href="">Enterprise Cloud</a></li>
                                            <li><a href="">Enterprise Cloud</a></li>
                                            <li><a href="">Cloud SaaS & Apps</a></li>
                                            <li><a href="">Cloud with load balancer dedicated firewall and clustering</a></li>
                                            <li><a href="">Cloud CDN</a></li>
                                            <li><a href="">White labelled Cloud</a></li>
                                            <li><a href="">Cloud Comparison</a></li>
                                        </ul>
                                    </li>
                                    <li style="border-right:2px solid grey">
                                        <a href="dedicated-server.php">DEDICATED SERVER</a>
                                        <ul class="dropdown">
                                           <li><a href="">Power Servers</a></li>
                                            <li><a href="">Value Servers</a></li>
                                            <li><a href="">Value Servers</a></li>
                                            <li><a href="">US Servers</a></li>
                                            <li><a href="load-balancer.php">Load Balancer, Cluster and Firewall</a></li>
                                        </ul>
                                    </li>
                                    <li style="border-right:2px solid grey">
                                        <a href="colocation.php">COLOCATION</a>
                                        <ul class="dropdown">
                                            <li><a href="server-colocation.php">Server Colocation</a></li>
                                            <li><a href="rack-space.php">Rack Space</a></li>
                                            <li><a href="high-density-colocation.php">High Density Colocation</a></li>
                                        </ul>
                                    </li>
                                    <li style="border-right:2px solid grey">
                                        <a href="business.php">BUSINESS SOLUTION</a>
                                        <ul class="dropdown">
                                            <li><a href="hosted_exchange.php">Hosted Exchange & Zimbra</a></li>
                                            <li><a href="disaster_recovery.php">Disaster Recovery</a></li>
                                            <li><a href="work_area_recovery.php">Work area Recovery (BCP Seats)</a></li>
                                            <li><a href="hosted_dynamics.php">Hosted Dynamics, Navision and Sharepoint</a></li>
                                            <li><a href="desktop_service.php">Desktop as a Service</a></li>
                                            <li><a href="application_monitoring.php">Application Monitoring & Performance</a></li>
                                             <li><a href="ssl_certificates.php">SSL Certificates</a></li>
                                        </ul>
                                    </li>
                                     <li>
                                        <a href="about-us.php">ABOUT US</a>
                                        <ul class="dropdown">
                                            <!--<li><a href="leadership_team.php">Leadership Team</a></li>-->
                                            <!--<li><a href="">Certifications</a></li>-->
                                            <!--<li><a href="">Aries Insights</a></li>-->
                                            <!--<li><a href="">Clients</a></li>-->
                                            <!--<li><a href="why_aries.php">Why Aries?</a></li>-->
                                            <!--<li><a href="">Life at CtrlS</a></li>-->
                                            <!--<li><a href="">Contact Us</a></li>-->
                                            <li><a href="career.php">Careers</a></li>
                                        </ul>
                                     </li>
                                </ul>
                            </div>
                            <!-- Nav End -->
                        </div>

                        <!-- Calling Info -->
                        <!-- <div class="calling-info">
                            <div class="call-center">
                                <a href="tel:+654563325568889"><i class="icon-telephone-2"></i> <span>(+65) 456 332 5568 889</span></a>
                            </div>
                        </div> -->
                    </nav>
                </div>
            </div>
        </div>
    </header>