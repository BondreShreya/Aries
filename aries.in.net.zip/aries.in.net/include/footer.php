  <footer class="footer-area">
        <div class="main-footer-area pt-4">
            <div class="container">
                <div class="row">
                    <!-- Footer Widget Area -->
                    <div class="col-12 col-sm-6 col-lg-3">
                        <div class="footer-widget">
                            <div class="widget-title">
                                <h6>CLOUD</h6>
                            </div>
                            <a href="#" class="link-color">Real Cloud</a><br>
                            <a href="#" class="link-color">4Copy Public Cloud</a><br>
                            <a href="#" class="link-color">Enterprise Cloud</a><br>
                            <a href="#" class="link-color">Cloud Backup & Storage</a>
                           
                        </div>
                    </div>
                    <!-- Footer Widget Area -->
                    <div class="col-12 col-sm-6 col-lg-3">
                        <div class="footer-widget">
                            <div class="widget-title">
                                <h6>DEDECATED SERVER</h6>
                            </div>
                            <a href="#" class="link-color">Power Servers</a><br>
                            <a href="#" class="link-color">US Servers</a><br>
                            <a href="#" class="link-color">Managed Virtualization Server</a><br>
                           


                        </div>
                    </div>
                    <!-- Footer Widget Area -->
                    <div class="col-12 col-sm-6 col-lg-3">
                        <div class="footer-widget">
                            <div class="widget-title">
                                <h6>COLOCATION</h6>
                            </div>
                                <a href="#" class="link-color">Server Colocation</a><br>
                                <a href="#" class="link-color">Rack Space Colocation</a><br>
                                <a href="#" class="link-color">High Density Colocation</a><br>
                           
                        </div>
                    </div>
                    <!-- Footer Widget Area -->
                    <div class="col-12 col-sm-6 col-lg-3">
                        <div class="footer-widget">
                            <div class="widget-title">
                                <h6>BUSINESS SOLUTION</h6>
                            </div>
                            <a href="#" class="link-color">Hosted Exchange & Zimbra</a><br>
                            <a href="#" class="link-color">Cold, Warm and Hot DR</a><br>
                            <a href="#" class="link-color">Desktop as a Service</a><br>
                            <a href="#" class="link-color">Virtual Datacenter</a>
                        </div>

                    </div>
                  <div class="col-12 mt-3 mb-3" style="border-bottom:1px solid grey"></div>
                </div>
                
            </div>
            <div class="container">
                <div class="row">
                    <!-- Footer Widget Area -->
                    <div class="col-12 col-sm-6 col-lg-6">
                        <div class="footer-widget">
                            <div class="footer-social-info">
                                <a href="#"><p>SERVER <br>UPTIME</p></a>
                                <a href="#"><p class="text-white">456</p>
                                    <p>DAYS</p>
                                </a>
                                <a href="#"><p class="text-white">45</p>
                                    <p>HOURS</p>
                                </a>
                                <a href="#"><p class="text-white">30</p>
                                    <p>MINUTES</p>
                                </a>
                                <a href="#"><p class="text-white">2</p> 
                                    <p>SECOND</p>
                                </a>
                            </div>
                           
                        </div>
                    </div>
                    <!-- Footer Widget Area -->
                    <div class="col-12 col-md-12 col-sm-6 col-lg-2 ">
                        <div class="footer-widget" style="border-right:1px dotted grey">
                            <div class="widget-title">
                                <h6 class="text-muted">1800-102-8757</h6>
                                 <p>ales Toll Free Number</p>
                            </div>
                          


                        </div>
                    </div>
                    <!-- Footer Widget Area -->
                    <div class="col-12 col-md-12 col-sm-6 col-lg-2">
                        <div class="footer-widget" style="border-right:1px dotted grey">
                            <div class="widget-title">
                                <h6 class="text-muted">FAQs</h6>
                                <p>Get help quickly</p>
                            </div>
                                
                           
                        </div>
                    </div>
                    <!-- Footer Widget Area -->
                    <div class="col-12 col-md-12 col-sm-6 col-lg-2">
                        <div class="footer-widget" style="border-right:1px dotted grey">
                            <div class="widget-title">
                                <h6 class="text-muted">buy@ctrls.com</h6>
                                <p>Request for proposal</p>

                            </div>
                            
                        </div>

                    </div>
                </div>
                
            </div>
        </div>
        <div class="bottom-footer-area">
             <div class="container">
                <div class="row">
                    <!-- Footer Widget Area -->
                    <div class="col-12 col-md-12 col-sm-6 col-lg-4">
                        <div class="footer-widget">
                           <p>       
                            Copyright Aries Datacenters Ltd 2007-2020.Privacy policyMSASLAAUPTermsBilling GuidelinesSitem</p>
                            
                        </div>
                    </div>
                    <!-- Footer Widget Area -->
                    <div class="col-12 col-md-12 col-sm-6 col-lg-4">
                        <div class="footer-widget">
                           <div class="footer-social-info">
                                <a href="#"><i class="fa fa-facebook text-white"></i></a>
                                <a href="#"><i class="fa fa-twitter text-white"></i></a>
                                <a href="#"><i class="fa fa-dribbble text-white"></i></a>
                                <a href="#"><i class="fa fa-behance text-white"></i></a>
                                <a href="#"><i class="fa fa-instagram text-white"></i></a>
                            </div>
                        </div>
                    </div>
                    <!-- Footer Widget Area -->
                   <div class="col-12 col-md-12 col-sm-6 col-lg-4">
                        <div class="footer-widget">
                           <div class="footer-social-info">
                                <a href="#"><i class="fa fa-facebook text-white"></i></a>
                                <a href="#"><i class="fa fa-twitter text-white"></i></a>
                                <a href="#"><i class="fa fa-dribbble text-white"></i></a>
                                <a href="#"><i class="fa fa-behance text-white"></i></a>
                                <a href="#"><i class="fa fa-instagram text-white"></i></a>
                            </div>
                        </div>
                    </div>
                    <!-- Footer Widget Area -->

                </div>
            </div>
        </div>
    </footer>