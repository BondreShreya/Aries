<!DOCTYPE html>
<html lang="en">

 <?php include('include/head.php'); ?>
<style>
    td{
        text-align:center;
        
    }
     table, td, th {
     border: 1px dotted;
     padding:8px;
    
    }
    th{
        color:#218a80;
    }
    
    #table1 {
      border-collapse: separate;
    }

</style>
<body>
    <!-- ##### Preloader ##### -->
    <div id="preloader">
        <i class="circle-preloader"></i>
    </div>

    <!-- ##### Header Area Start ##### -->
   <?php include('include/header.php'); ?>
    <!-- ##### Header Area End ##### -->

    <!-- ##### Hero Area Start ##### -->
    <section class="hero-area">
        <div class="hero-slides owl-carousel">

            <!-- Single Hero Slide -->
            <div class="single-hero-slide1 bg-img" style="background-image: url(img/bg-img/a6.jpg);">
                <div class="container h-100">
                    <div class="row h-100 align-items-center">
                        <div class="col-12 text-center">
                             <div class="row">
                          <div class="col-12 col-md-6">
                            <h3 class="text-white pb-2 line">Server
                        <span class="text-primary">Colocation</span></h3>
                               
                          </div>
                              <div class="col-12 col-md-6"> 
                                  <p class="text-justify text-white">Choose from a wide range of cabinet space we offer. 10 GBPS Bandwidth Connectivity from all the major Telco’s in India. 24 x 7 x 365 monitoring by industry certified on-site staff.</p>
                              </div>
                        </div>
                        </div>
                    </div>
                        </div>
                    </div>
                    <!-- Single Hero Slide -->
        
            </div>
        </section>
        <!-- ##### Hero Area End ##### -->
    
        <section>
            <nav aria-label="breadcrumb">
              <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                <li class="breadcrumb-item active" aria-current="page"><a href="colocation.php">Colocation</a></li>
                <li class="breadcrumb-item">Server Colocation</li>
              </ol>
            </nav>
        </section>
       <section>
        <div class="partner-area">
            <div class="container">
                 <div class="row">
                    <div class="col-md-12">
                        <div class="row">
                            <div class="col-md-12">
                            <h5 style="color: #021058">PLANS & PRICING</h5>
                            </div>
                        </div>
                        
                         <div class="row">
                          <div class="col-md-12">
                                 <table id="table1" class="table-responsive">
                                    <thead>
                                      <tr>
                                        <th></th>
                                        <th class="text-center">1 U Bundle</th>
                                        <th class="text-center">2 U Bundles</th>
                                        <th class="text-center">4 U Bundles</th>
                                        <th class="text-center">8 U Bundles</th>
                                    </thead>
                                    <tbody>
                                      <tr>
                                        <th>Units</th>
                                        <td>1</td>
                                        <td>2</td>
                                        <td>4</td>
                                        <td>8</td>
                                      </tr>
                                      <tr>
                                        <th>Bandwidth</th>
                                        <td>100 GB</td>
                                        <td>100 GB</td>
                                        <td>100 GB</td>
                                        <td>100 GB</td>
                                      </tr>
                                      <tr>
                                        <th>IP's</th>
                                        <td>2</td>
                                        <td>2</td>
                                        <td>2</td>
                                        <td>2</td>
                                      </tr>
                                      <tr>
                                        <th>Free Reboots</th>
                                        <td>Yes</td>
                                        <td>Yes</td>
                                        <td>Yes</td>
                                        <td>Yes</td>
                                      </tr>
                                      <tr>
                                        <th>Free Setup</th>
                                         <td>Yes</td>
                                        <td>Yes</td>
                                        <td>Yes</td>
                                        <td>Yes</td>
                                      </tr>
                                      <tr>
                                        <th>KVM Access</th>
                                        <td>On Demand</td>
                                        <td>On Demand</td>
                                        <td>On Demand</td>
                                        <td>On Demand</td>
                                      </tr>
                                      <tr>
                                        <th>Rated Power</th>
                                        <td>200W</td>
                                        <td>300W</td>
                                        <td>400W</td>
                                        <td>600W</td>
                                      </tr>
                                      <tr>
                                        <th>Power Supply</th>
                                         <td>Yes</td>
                                        <td>Yes</td>
                                        <td>Yes</td>
                                        <td>Yes</td>
                                      </tr>
                                      <td></td>
                                      <td>
                                        <ul class="linebox">
                                           <li class="pr-3" style="color:red"><b>5,000/mo.</b></li>
                                           <li class="pr-3"><a href="#" class="btn academy-btn btn-sm">SEE PLANS</a> </li>
                                        </ul>
                                      </td>
                                        <td>
                                            <ul class="linebox">
                                           <li class="pr-3" style="color:red"><b>5,000/mo.</b></li>
                                           <li class="pr-3"> <a href="#" class="btn academy-btn btn-sm">SEE PLANS</a></li>
                                       </ul>  
                                       </td>
                                        <td>
                                            <ul class="linebox">
                                           <li class="pr-3" style="color:red"><b>5,000/mo.</b></li>
                                           <li class="pr-3"> <a href="#" class="btn academy-btn btn-sm">SEE PLANS</a> </li>
                                       </ul>  
                                        </td>
                                        <td>
                                            <ul class="linebox">
                                           <li class="pr-3" style="color:red"><b>5,000/mo.</b></li>
                                           <li class="pr-3"> <a href="#" class="btn academy-btn btn-sm">SEE PLANS</a> </li>
                                       </ul>  
                                        </td>
                                      </tr>
                                    </tbody>
                                </table>
                          </div>
                             
                        </div>
                    </div>
                </div>
            </div>
        </div>
   </section>
    <!-- ##### ##### -->
    <div class="partner-area pt-5">
        <div class="container">
                 <div class="row">
                    <div class="col-md-9">
                        <div class="row p-3" style="border-top: 2px dotted #80808059;">
                          <div class="col-12">
                                  <div class="text-center">
                                   <p class="text-justify">At Aries Data Centers, we have no priority greater than keeping your applications online and we take that very seriously. Our commitment to take total ownership of the project has resulted in a client portfolio featuring some of the most renowned names in industry as well as the young entrepreneur who’s cloud software needs secure, continual hosting.</p>
                                   <p class="text-justify">Our facilities are carrier-neutral with datacenter specialists ready to assist you and prove a customized turnkey colocation service. Be assured that your server uptime is best in class and without compromise.</p>
                                </div>
                          </div>
                        </div>
                        <div class="row">
                           <div class="col-12">                              
                            <h6 style="color: #021058">Below are some of the advantages of having your server colocated with us:</h6>
                                <ul class="text-justify">
                                    <li>* 10 GBPS Bandwidth Connectivity from all the major Telco’s in India</li>
                                    <li>* 24x7x365 monitoring by industry certified on-site staff.</li>
                                    <li>* 100% uptime Network as we have dual Active network paths including N+N redundancy for Firewall, routers and switches thereby eliminating any single point of failure.</li>
                                    <li>* Highly Sophisticated fire detection (VESDA) and FM-200 gas based fire suppression systems.</li>
                                    <li>* Advanced HVAC(Heating, Ventilating, and Air Conditioning) systems providing optimal server operating conditions.</li>
                                    <li>* Perimeter level firewall to ensure that your servers are always safe from hackers and malicious attacks over the internet.</li>
                                    <li>* Global certifications ISO 20000-1 for service delivery and ISO 27001 for data security.</li>
                                    <li>* All the above backed by six zone security thereby ensuring that your data is protected and available at all times.</li>
                                </ul>
                          </div>
                        </div>
                    </div>
                    
                    <div class="col-md-3">
                        <div class="box">
                        <div class="row">
                            <h6 style="color: #021058">Need help deciding?</h6>
                            <p>CONTACT US</p>
                        </div>
                            <div class="row">
                               
                                <div class="col-3">
                                    <i class="fa fa-headphones" aria-hidden="true"></i>
                                </div>
                                <div class="col-9"> 
                                        <p><b style="color: #021058">1800-102-8757</b></p>
                                        <p>Sales Toll Free Number</p>
                                </div>
                            </div> 
                           </div>
                         
                            <div class="box mt-3">
                        
                            <div class="row">
                               
                                <div class="col-12">
                                     
                                    <div id="myCarousel" class="carousel slide" data-ride="carousel">
                                        <h6 style="color: #021058">Testimonials</h6> 
                                <!-- Carousel indicators -->
                                 
                                <!-- Wrapper for carousel items -->
                                <div class="carousel-inner">  
                                    
                                    <div class="item carousel-item active">
                                        
                                        <p class="testimonial">Aries maintains good relationships and follows up regularly about the service, to ensure that everything goes smoothly.</p>
                                        <h6>Mr.Manoj Patel</h6>
                                             <p>Relay Express</p>
                                    </div>


                                    <div class="item carousel-item">
                                        
                                        <p class="testimonial">Migration to Cloud was made so easy by CtrlS.Server was installed and set up without any problems, most importantly, zero downtime.
                                       </p>
                                       <h6>Mr.NVV Krishnam Raju</h6>
                                             <p>Seventeen Networks</p>
                                        
                                    </div>
                                        
                                                                    </div>
                                        <!-- Carousel controls -->
                                        <a class="carousel-control left carousel-control-prev" href="#myCarousel" data-slide="prev">
                                            <i class="fa fa-angle-left"></i>
                                        </a>
                                        <a class="carousel-control right carousel-control-next" href="#myCarousel" data-slide="next">
                                            <i class="fa fa-angle-right"></i>
                                        </a>
                                    </div>
                                </div>
                               
                            </div> 
                           </div> 
                        </div> 
                        </div>

                    </div>
                 </div>

            </div>

        </div>
    </div>
    <!-- #####  ##### -->
  <!-- ##### Partner Area Start ##### -->
    <div class="partner-area pt-5 pb-5">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <h5 style="color: #021058">A FEW OF OUR MORE RECOGNIZABLE CLIENTS</h5>
                    <div class="partners-logo d-flex align-items-center justify-content-between  mt-5">
                        <a href="#"><img src="img/clients-img/partner-1.png" alt=""></a>
                        <a href="#"><img src="img/clients-img/partner-2.png" alt=""></a>
                        <a href="#"><img src="img/clients-img/partner-3.png" alt=""></a>
                        <a href="#"><img src="img/clients-img/partner-4.png" alt=""></a>
                        <a href="#"><img src="img/clients-img/partner-5.png" alt=""></a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- ##### Partner Area End ##### -->
   

    <!-- ##### Footer Area Start ##### -->
   <?php include('include/footer.php'); ?>
    <!-- ##### Footer Area Start ##### -->

    <!-- ##### All Javascript Script ##### -->
    <!-- jQuery-2.2.4 js -->
    <script src="js/jquery/jquery-2.2.4.min.js"></script>
    <!-- Popper js -->
    <script src="js/bootstrap/popper.min.js"></script>
    <!-- Bootstrap js -->
    <script src="js/bootstrap/bootstrap.min.js"></script>
    <!-- All Plugins js -->
    <script src="js/plugins/plugins.js"></script>
    <!-- Active js -->
    <script src="js/active.js"></script>
</body>

</html>