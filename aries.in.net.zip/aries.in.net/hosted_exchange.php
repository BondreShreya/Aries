<!DOCTYPE html>
<html lang="en">

 <?php include('include/head.php'); ?>
<style>
    td{
        text-align:center;
    }
     table, td, th {
     border: 1px dotted;
     padding:8px;
    
    }
    
    #table1 {
      border-collapse: separate;
    }

</style>
<body>
    <!-- ##### Preloader ##### -->
    <div id="preloader">
        <i class="circle-preloader"></i>
    </div>

    <!-- ##### Header Area Start ##### -->
   <?php include('include/header.php'); ?>
    <!-- ##### Header Area End ##### -->

    <!-- ##### Hero Area Start ##### -->
    <section class="hero-area">
        <div class="hero-slides owl-carousel">

            <!-- Single Hero Slide -->
            <div class="single-hero-slide1 bg-img" style="background-image: url(img/bg-img/a6.jpg);">
                <div class="container h-100">
                    <div class="row h-100 align-items-center">
                        <div class="col-12 text-center">
                             <div class="row">
                          <div class="col-12 col-md-6">
                            <h2 class="text-white pb-2 line">Hosted Exchange<br>
                           <span class="text-primary">& Zimbra</span></h2>
                               
                          </div>
                              <div class="col-12 col-md-6"> 
                                  <p class="text-justify text-white">Leave your critical mailing systems in the care of Aries. We offer fully managed mailing solutions to take care of your mission critical and highly valuable Emailing tasks.</p>
                              </div>
                        </div>
                            <!--<div class="hero-slides-content">-->
                           
                           

                            <!--</div>-->
                        </div>
                    </div>
                        </div>
                    </div>
                    <!-- Single Hero Slide -->
        
            </div>
        </section>
        <!-- ##### Hero Area End ##### -->
    
        <section>
            <nav aria-label="breadcrumb">
              <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                <li class="breadcrumb-item active" aria-current="page"><a href="business.php">Business Solution</a></li>
                <li class="breadcrumb-item">Hosted Exchange & Zimbra</li>
              </ol>
            </nav>
        </section>
   <!--    <section>-->
   <!--     <div class="partner-area">-->
   <!--         <div class="container">-->
   <!--              <div class="row">-->
   <!--                 <div class="col-md-12">-->
   <!--                     <div class="row">-->
   <!--                         <div class="col-md-12">-->
   <!--                         <h5 style="color: #021058">PLANS & PRICING</h5>-->
   <!--                         </div>-->
   <!--                     </div>-->
                        
   <!--                      <div class="row">-->
   <!--                       <div class="col-md-12">-->
   <!--                              <table id="table1">-->
   <!--                                 <thead>-->
   <!--                                   <tr>-->
   <!--                                     <th></th>-->
   <!--                                     <th class="text-center">1 U Bundle</th>-->
   <!--                                     <th class="text-center">2 U Bundles</th>-->
   <!--                                     <th class="text-center">4 U Bundles</th>-->
   <!--                                     <th class="text-center">8 U Bundles</th>-->
   <!--                                 </thead>-->
   <!--                                 <tbody>-->
   <!--                                   <tr>-->
   <!--                                     <th>Units</th>-->
   <!--                                     <td>1</td>-->
   <!--                                     <td>2</td>-->
   <!--                                     <td>4</td>-->
   <!--                                     <td>8</td>-->
   <!--                                   </tr>-->
   <!--                                   <tr>-->
   <!--                                     <th>Bandwidth</th>-->
   <!--                                     <td>100 GB</td>-->
   <!--                                     <td>100 GB</td>-->
   <!--                                     <td>100 GB</td>-->
   <!--                                     <td>100 GB</td>-->
   <!--                                   </tr>-->
   <!--                                   <tr>-->
   <!--                                     <th>IP's</th>-->
   <!--                                     <td>2</td>-->
   <!--                                     <td>2</td>-->
   <!--                                     <td>2</td>-->
   <!--                                     <td>2</td>-->
   <!--                                   </tr>-->
   <!--                                   <tr>-->
   <!--                                     <th>Free Reboots</th>-->
   <!--                                     <td>Yes</td>-->
   <!--                                     <td>Yes</td>-->
   <!--                                     <td>Yes</td>-->
   <!--                                     <td>Yes</td>-->
   <!--                                   </tr>-->
   <!--                                   <tr>-->
   <!--                                     <th>Free Setup</th>-->
   <!--                                      <td>Yes</td>-->
   <!--                                     <td>Yes</td>-->
   <!--                                     <td>Yes</td>-->
   <!--                                     <td>Yes</td>-->
   <!--                                   </tr>-->
   <!--                                   <tr>-->
   <!--                                     <th>KVM Access</th>-->
   <!--                                     <td>On Demand</td>-->
   <!--                                     <td>On Demand</td>-->
   <!--                                     <td>On Demand</td>-->
   <!--                                     <td>On Demand</td>-->
   <!--                                   </tr>-->
   <!--                                   <tr>-->
   <!--                                     <th>Rated Power</th>-->
   <!--                                     <td>200W</td>-->
   <!--                                     <td>300W</td>-->
   <!--                                     <td>400W</td>-->
   <!--                                     <td>600W</td>-->
   <!--                                   </tr>-->
   <!--                                   <tr>-->
   <!--                                     <th>Power Supply</th>-->
   <!--                                      <td>Yes</td>-->
   <!--                                     <td>Yes</td>-->
   <!--                                     <td>Yes</td>-->
   <!--                                     <td>Yes</td>-->
   <!--                                   </tr>-->
   <!--                                   <td></td>-->
   <!--                                   <td>-->
   <!--                                     <ul class="linebox">-->
   <!--                                        <li class="pr-3" style="color:red"><b>5,000/mo.</b></li>-->
   <!--                                        <li class="pr-3"><a href="#" class="btn academy-btn btn-sm mb-5">SEE PLANS</a> </li>-->
   <!--                                     </ul>-->
   <!--                                   </td>-->
   <!--                                     <td>-->
   <!--                                         <ul class="linebox">-->
   <!--                                        <li class="pr-3" style="color:red"><b>5,000/mo.</b></li>-->
   <!--                                        <li class="pr-3"> <a href="#" class="btn academy-btn btn-sm mb-5">SEE PLANS</a></li>-->
   <!--                                    </ul>  -->
   <!--                                    </td>-->
   <!--                                     <td>-->
   <!--                                         <ul class="linebox">-->
   <!--                                        <li class="pr-3" style="color:red"><b>5,000/mo.</b></li>-->
   <!--                                        <li class="pr-3"> <a href="#" class="btn academy-btn btn-sm mb-5">SEE PLANS</a> </li>-->
   <!--                                    </ul>  -->
   <!--                                     </td>-->
   <!--                                     <td>-->
   <!--                                         <ul class="linebox">-->
   <!--                                        <li class="pr-3" style="color:red"><b>5,000/mo.</b></li>-->
   <!--                                        <li class="pr-3"> <a href="#" class="btn academy-btn btn-sm mb-5">SEE PLANS</a> </li>-->
   <!--                                    </ul>  -->
   <!--                                     </td>-->
   <!--                                   </tr>-->
   <!--                                 </tbody>-->
   <!--                             </table>-->
   <!--                       </div>-->
                             
   <!--                     </div>-->
   <!--                 </div>-->
   <!--             </div>-->
   <!--         </div>-->
   <!--     </div>-->
   <!--</section>-->
    <!-- ##### ##### -->
    <div class="partner-area pt-5">
        <div class="container">
                 <div class="row">
                    <div class="col-md-9">
                        <div class="row">
                          <div class="col-12">
                                  <div class="text-center table-responsive">
                             <table class="table table-striped">
                                <thead>
                                  <tr class="table-info">
                                    <th>Features</th>
                                    <th>Qmail</th>
                                    <th>Zimbra</th>
                                    <th>Basic Exchange</th>
                                    <th>Adv Exchange</th>
                                    <th>Ent Exchange</th>
                                  </tr>
                                </thead>
                                <tbody>
                                  <tr>
                                     <td>POP3</td>
                                     <td>Yes</td>
                                     <td>Yes</td>
                                     <td>Yes</td>
                                     <td>Yes</td>
                                     <td>Yes</td>
                                  </tr>
                                 <tr>
                                     <td>IMAP</td>
                                     <td>Yes</td>
                                     <td>Yes</td>
                                     <td>Yes</td>
                                     <td>Yes</td>
                                     <td>Yes</td>
                                  </tr>
                                  <tr>
                                     <td>Webmail</td>
                                     <td>Yes</td>
                                     <td>Yes</td>
                                     <td>Yes</td>
                                     <td>Yes</td>
                                     <td>Yes</td>
                                  </tr>
                                  <tr>
                                     <td>MAPI</td>
                                     <td>No</td>
                                     <td>No</td>
                                     <td>No</td>
                                     <td>Yes</td>
                                     <td>Yes</td>
                                  </tr>
                                  <tr>
                                     <td>Filter</td>
                                     <td>Anti-Virus</td>
                                     <td>Anti-Virus</td>
                                     <td>Anti-Virus</td>
                                     <td>Anti-Virus</td>
                                     <td>Anti-Virus</td>
                                  </tr>
                                  <tr>
                                     <td>Filter</td>
                                     <td>Anti-Spam</td>
                                     <td>Anti-Spam</td>
                                     <td>Anti-Spam</td>
                                     <td>Anti-Spam</td>
                                     <td>Anti-Spam</td>
                                  </tr>
                                  <tr>
                                     <td>Mail Box Size</td>
                                     <td>500 MB</td>
                                     <td>500 MB</td>
                                     <td>500 MB</td>
                                     <td>1 GB</td>
                                     <td>1 GB</td>
                                  </tr>
                                  <tr>
                                     <td>Blackberry Enterprise Server</td>
                                     <td>No</td>
                                     <td>No</td>
                                     <td>No</td>
                                     <td>No</td>
                                     <td>Yes</td>
                                  </tr>
                                  <tr>
                                     <td>Calendar Sharing</td>
                                     <td>No</td>
                                     <td>No</td>
                                     <td>No</td>
                                     <td>Yes</td>
                                     <td>Yes</td>
                                  </tr>
                                  <tr>
                                     <td>Global Address Book</td>
                                     <td>No</td>
                                     <td>Yes</td>
                                     <td>Yes</td>
                                     <td>Yes</td>
                                     <td>Yes</td>
                                  </tr>
                                  <tr>
                                     <td>Price in INR per year</td>
                                     <td>Rs. 420</td>
                                     <td>Rs. 840</td>
                                     <td>Rs. 1200</td>
                                     <td>Rs. 3600</td>
                                     <td>Rs. 6000</td>
                                  </tr>
                                  <tr>
                                     <td>Backup</td>
                                     <td>No</td>
                                     <td>Yes</td>
                                     <td>Yes</td>
                                     <td>Yes</td>
                                     <td>Yes</td>
                                  </tr>
                                  <tr>
                                     <td>Managed</td>
                                     <td>No</td>
                                     <td>Yes</td>
                                     <td>Yes</td>
                                     <td>Yes</td>
                                     <td>Yes</td>
                                  </tr>
                                  <tr>
                                     <td>Managed Email / Mail Box / Year</td>
                                     <td>Rs. 300</td>
                                     <td>Rs. 600</td>
                                     <td>Rs. 600</td>
                                     <td>Rs. 600</td>
                                     <td>Rs. 600</td>
                                  </tr>
                                </tbody>
                              </table>
                                </div>
                          </div>
                        </div>
                        <div class="row p-3" style="border-top: 2px dotted #80808059;">
                           <div class="col-12">                              
                            <h6 style="color: #021058">MAIL & MESSAGING</h6>
                                <ul>
                                    <li>Leave your critical mailing systems in the care of Aries. We offer fully managed mailing solutions to take care of your mission critical and highly valuable Emailing tasks.</li><br>
                                    <li>Aries Mail & Messaging solutions come bundled up with Anti-SPAM and Anti-Virus services. We offer a pay per use mailbox plans that save huge revenues to your Organization.</li><br>
                                    <li>Aries provides an important platform for managing heavy traffic that flows through your Emails in a very secure and confidential environment which is very critical for maintaining business privacy.</li><br>
                                </ul>
                          </div>
                          <div class="col-12">                              
                            <h6 style="color: #021058">Aries provides Email Hosting Solutions for:</h6>
                                <ul>
                                    <li>* Dedicated Zimbra</li>
                                    <li>* Dedicated Exchange</li>
                                    <li>* Hosted Exchange</li>
                                    <li>* Email Servers</li>
                                    <li>* Hybrid Servers</li><br>
                                </ul>
                          </div>
                          <div class="col-12">                              
                            <h6 style="color: #021058">Our Features include:</h6>
                                <ul>
                                    <li>* POP / SMTP / IMAP</li>
                                    <li>* Webmail</li>
                                    <li>* Document Management</li>
                                    <li>* Task Management</li>
                                    <li>* Highest possible security features</li>
                                    <li>* Anti-SPAM</li>
                                    <li>* Anti-Virus</li>
                                    <li>* Blackberry Email Services</li>
                                </ul>
                          </div>
                        </div>
                    </div>
                    
                    <div class="col-md-3">
                        <div class="box">
                        <div class="row">
                            <h6 style="color: #021058">Need help deciding?</h6>
                            <p>CONTACT US</p>
                        </div>
                            <div class="row">
                               
                                <div class="col-3">
                                    <i class="fa fa-headphones" aria-hidden="true"></i>
                                </div>
                                <div class="col-9"> 
                                        <p><b style="color: #021058">1800-102-8757</b></p>
                                        <p>Sales Toll Free Number</p>
                                </div>
                            </div> 
                           </div>
                            
                           <!-- <div class="box mt-3">-->
                           <!--     <div id="crmWebToEntityForm" class="form-box">-->
                           <!--        <meta http-equiv="content-type" content="text/html;charset=UTF-8">-->
                           <!--     	<form action="" name="WebToLeads2569189000036821042" method="POST" onsubmit="javascript:document.charset=&quot;UTF-8&quot;; return checkMandatory2569189000036821042()" accept-charset="UTF-8" siq_id="autopick_4437">-->
                           <!--     		<input type="text" style="display:none;" name="xnQsjsdp" value="5bbf9f74877d7cbf151ef666b662b48a23ff284067d965528e240073aedb838e"> -->
                           <!--      <input type="hidden" name="zc_gad" id="zc_gad" value=""> -->
                           <!--      <input type="text" style="display:none;" name="xmIwtLD" value="32ce659de9c603b6bad36dc19a4b9268a1e34860f3aae765e5c067e4d81d605e"> -->
                           <!--      <input type="text" style="display:none;" name="actionType" value="TGVhZHM=">-->
                           <!--     <input type="text" style="display:none;" name="returnURL" value="https://www.ctrls.com/thankyou.php"> -->
                                				
                           <!--     		<h6 style="color: #021058">Sounds good?<span>Fill up the form below &amp; Get Attractive Offers</span></h6>-->
                           <!--     		<ul>-->
                           <!--     			<li>-->
                           <!--     				<label>Name<span style="color:red;">*</span></label>-->
                           <!--     				<input type="text" class="form-control" maxlength="80" name="Last Name">-->
                           <!--     			</li>-->
                           <!--     			<li>-->
                           <!--     				<label>Your email address<span style="color:red;">*</span></label>-->
                           <!--     				<input type="text" class="form-control" id="email" maxlength="100" name="Email">-->
                           <!--     			</li>-->
                           <!--     			<li>-->
                           <!--     				<label>Phone number<span style="color:red;">*</span></label>-->
                           <!--     				<input type="text" class="form-control" id="phone" maxlength="30" name="Phone">-->
                           <!--     			</li>-->
                                
                           <!--     			<li>-->
                           <!--     				<label>Comments</label>-->
                           <!--     				<textarea class="form-control" id="msg" name="Description" maxlength="32000" rows="3" style="height: 50px !important;">&nbsp;</textarea>-->
                           <!--     			</li><br>-->
                                			
                           <!--     			<li>-->
                           <!--     				<img id="imgid" src="https://crm.zoho.com/crm/CaptchaServlet?formId=32ce659de9c603b6bad36dc19a4b9268a1e34860f3aae765e5c067e4d81d605e&amp;grpid=5bbf9f74877d7cbf151ef666b662b48a23ff284067d965528e240073aedb838e"><br>-->
                                
                           <!--     				<label>Enter the code above here :</label><br>-->
                                
                           <!--     				<input type="text" class="form-control" maxlength="80" name="enterdigest"><br>-->
                           <!--     				<small>Can't read the image? click <a href="javascript:;" onclick="reloadImg()">here</a> to refresh</small>-->
                                				
                           <!--     			</li>-->
                           <!--     			<li style="display:none;">-->
                           <!--     				<label>Lead Source</label>-->
                           <!--     				<select name="Lead Source">-->
                           <!--     					<option value="-None-">-None-</option>-->
                           <!--     					<option value="Cloud4C Google Ads">Cloud4C Google Ads</option>-->
                           <!--     					<option value="CtrlS.com">CtrlS.com</option>-->
                           <!--     					<option value="Cloud4C.com Google Adwords">Cloud4C.com Google Adwords</option>-->
                           <!--     					<option value="Cloud4c.com LivServ">Cloud4c.com LivServ</option>-->
                           <!--     					<option value="Cloud4C.com SalesIQ Chat">Cloud4C.com SalesIQ Chat</option>-->
                           <!--     					<option value="Cloud4C.com Website">Cloud4C.com Website</option>-->
                           <!--     					<option value="Colocation-ctrlS.com">Colocation-ctrlS.com</option>-->
                           <!--     					<option value="Colocation-ctrlS.com - Chat">Colocation-ctrlS.com - Chat</option>-->
                           <!--     					<option value="CtrlS Google Ads">CtrlS Google Ads</option>-->
                           <!--     					<option value="CtrlS.com - Data Center">CtrlS.com - Data Center</option>-->
                           <!--     					<option value="CtrlS.com - Data Center - Chat">CtrlS.com - Data Center - Chat</option>-->
                           <!--     					<option value="CtrlS.com Google Adwords">CtrlS.com Google Adwords</option>-->
                           <!--     					<option value="CtrlS.com SalesIQ Chat">CtrlS.com SalesIQ Chat</option>-->
                           <!--     					<option selected="" value="CtrlS.com Website">CtrlS.com Website</option>-->
                           <!--     					<option value="Ctrls.in Chat">Ctrls.in Chat</option>-->
                           <!--     					<option value="CtrlS.in SalesIQ Chat">CtrlS.in SalesIQ Chat</option>-->
                           <!--     					<option value="CtrlS.in Website">CtrlS.in Website</option>-->
                           <!--     					<option value="Downloads Cloud4C">Downloads Cloud4C</option>-->
                           <!--     					<option value="Downloads CtrlS">Downloads CtrlS</option>-->
                           <!--     					<option value="Email Marketing">Email Marketing</option>-->
                           <!--     					<option value="Form Fills Cloud4C">Form Fills Cloud4C</option>-->
                           <!--     					<option value="Form Fills CtrlS">Form Fills CtrlS</option>-->
                           <!--     					<option value="Human Resource">Human Resource</option>-->
                           <!--     					<option value="Linkedin">Linkedin</option>-->
                           <!--     					<option value="Managed services - Facebook">Managed services - Facebook</option>-->
                           <!--     					<option value="Managed services - Google">Managed services - Google</option>-->
                           <!--     					<option value="Marketing Cloud4C">Marketing Cloud4C</option>-->
                           <!--     					<option value="Marketing CtrlS">Marketing CtrlS</option>-->
                           <!--     					<option value="Publishers">Publishers</option>-->
                           <!--     					<option value="Referrals">Referrals</option>-->
                           <!--     					<option value="Registration">Registration</option>-->
                           <!--     					<option value="Toll Free Cloud4C">Toll Free Cloud4C</option>-->
                           <!--     					<option value="Toll Free CtrlS">Toll Free CtrlS</option>-->
                           <!--     				</select>-->
                           <!--     			</li>-->
                           <!--     			<li style="display:none;">-->
                           <!--     				<label>Page URL</label>-->
                           <!--     				<textarea id="pageUrl" name="LEADCF2" maxlength="2000"></textarea>-->
                           <!--     			</li>-->
                           <!--     			<li style="display:none;">-->
                           <!--     				<label>Paid Identifier</label>-->
                           <!--     				<select name="LEADCF14">-->
                           <!--     					<option value="-None-">-None-</option>-->
                           <!--     					<option value="Paid">Paid</option>-->
                           <!--     					<option selected="" value="Non Paid">Non Paid</option>-->
                           <!--     				</select>-->
                           <!--     			</li>-->
                           <!--     			<li>-->
                           <!--     				<input class="btn btn-success btn-block" style="color:#FFF; background:#090; font-size:15px;" id="formsubmit" type="submit" value="Submit">-->
                           <!--     			</li><br>-->
                           <!--     		</ul>-->
                                		
                           <!--     		<script>-->
                           <!--     			var newUrl = window.location.href;-->
                           <!--     			console.log('Page Url:', newUrl);-->
                                
                           <!--     			$(document).ready(function(){-->
                           <!--     				$('#pageUrl').val(newUrl);-->
                           <!--     			})-->
                                			
                           <!--     			function isEmail(email) {-->
                           <!--     				var pattern = new RegExp(/^((([a-z]|\d|[!#\$%&'\*\+\-\/=\?\^_`{\|}~]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])+(\.([a-z]|\d|[!#\$%&'\*\+\-\/=\?\^_`{\|}~]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])+)*)|((\x22)((((\x20|\x09)*(\x0d\x0a))?(\x20|\x09)+)?(([\x01-\x08\x0b\x0c\x0e-\x1f\x7f]|\x21|[\x23-\x5b]|[\x5d-\x7e]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(\\([\x01-\x09\x0b\x0c\x0d-\x7f]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]))))*(((\x20|\x09)*(\x0d\x0a))?(\x20|\x09)+)?(\x22)))@((([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.)+(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.?$/i);-->
                           <!--     				if (pattern.test(email)) {-->
                           <!--     					return true;-->
                           <!--     				}-->
                           <!--     				return false;-->
                           <!--     			}-->
                                
                           <!--     			var mndFileds=new Array('Last Name','Email','Phone', 'enterdigest');-->
                           <!--     			var fldLangVal=new Array('Name','Email address','Phone number', 'Captcha');-->
                           <!--     			var name='';-->
                           <!--     			var email='';-->
                                			
                                			<!--Do not remove this code.-->
                           <!--     			function reloadImg() {-->
                           <!--     				if(document.getElementById('imgid').src.indexOf('&d') !== -1 ) {-->
                           <!--     					document.getElementById('imgid').src=document.getElementById('imgid').src.substring(0,document.getElementById('imgid').src.indexOf('&d'))+'&d'+new Date().getTime();-->
                           <!--     				}  else {-->
                           <!--     					document.getElementById('imgid').src = document.getElementById('imgid').src+'&d'+new Date().getTime();-->
                           <!--     				} -->
                           <!--     			}-->
                           <!--     			function isPhone(phone) {-->
                           <!--     				if (!$.isNumeric(phone)) {-->
                           <!--     					return false;-->
                           <!--     				}-->
                           <!--     				if (phone.length < 10 || phone.length > 15) {-->
                           <!--     					return false;-->
                           <!--     				}-->
                           <!--     				return true;-->
                           <!--     			}-->
                                
                           <!--     			function checkMandatory2569189000036821042() {-->
                           <!--     				for(i=0;i<mndFileds.length;i++) {-->
                           <!--     					var fieldObj=document.forms['WebToLeads2569189000036821042'][mndFileds[i]];-->
                           <!--     					if(fieldObj) {-->
                           <!--     						if (((fieldObj.value).replace(/^\s+|\s+$/g, '')).length==0) {-->
                           <!--     							if(fieldObj.type =='file') { -->
                           <!--     								alert('Please select a file to upload.');-->
                           <!--     								fieldObj.focus();-->
                           <!--     								return false;-->
                           <!--     							}-->
                                							
                           <!--     							alert(fldLangVal[i] +' cannot be empty.');-->
                           <!--     							fieldObj.focus();-->
                           <!--     							return false;-->
                           <!--     						}  else if(fieldObj.nodeName=='SELECT') {-->
                           <!--     							if(fieldObj.options[fieldObj.selectedIndex].value=='-None-') {-->
                           <!--     								alert(fldLangVal[i] +' cannot be none.');-->
                           <!--     								fieldObj.focus();-->
                           <!--     								return false;-->
                           <!--     							}-->
                           <!--     						} else if(fieldObj.type =='checkbox'){-->
                           <!--     							if(fieldObj.checked == false){-->
                           <!--     								alert('Please accept  '+fldLangVal[i]);-->
                           <!--     								fieldObj.focus();-->
                           <!--     								return false;-->
                           <!--     							}-->
                           <!--     						} else if (fieldObj.name === "Email") {-->
                           <!--     							if (!isEmail(fieldObj.value)) {-->
                           <!--     								$("#email").focus();-->
                           <!--     								alert("Please enter valid email address");-->
                           <!--     								return false;-->
                           <!--     							}-->
                           <!--     						} else if (fieldObj.name === "Phone") {-->
                           <!--     							if (!isPhone(fieldObj.value)) {-->
                           <!--     								alert("Please enter a valid Phone Number");-->
                           <!--     								$("#phone").focus();-->
                           <!--     								return false;-->
                           <!--     							}-->
                           <!--     						} try {-->
                           <!--     							if(fieldObj.name == 'Last Name') {-->
                           <!--     								name = fieldObj.value;-->
                           <!--     							}-->
                           <!--     						} catch (e) {-->
                                
                           <!--     						}-->
                           <!--     					}-->
                           <!--     				}-->
                           <!--     				document.getElementById('formsubmit').disabled=true;-->
                           <!--     			}-->
                                			
                           <!--     		</script>-->
                           <!--     	</form>-->
                                	
                                	<!-- Do not remove this code. -->
                           <!--     	<iframe name="captchaFrame" style="display:none;" __idm_frm__="70"></iframe>-->
                           <!--     </div>-->
                           <!--</div>-->
                            <div class="box mt-3">
                        <div class="row">
                            <h6 style="color: #021058">Sounds good?</h6>
                            <p>FILL UP THE FORM BELOW & GET ATTRACTIVE OFFERS</p>
                        </div>
                            <div class="row">
                               
                                <div class="col-12">
                                    <form action="/action_page.php">
                                         <div class="form-group">
                                        <label for="name">Name</label>
                                        <input type="name" class="form-control" id="name">
                                      </div>
                                      <div class="form-group">
                                        <label for="email"> Your Email address</label>
                                        <input type="email" class="form-control" id="email">
                                      </div>
                                      <div class="form-group">
                                        <label for="pwd">Phone Number</label>
                                        <input type="password" class="form-control" id="pwd">
                                      </div>
                                       <div class="form-group">
                                        <label for="pwd">Comments</label>
                                        <textarea type="password" class="form-control" id="pwd"></textarea>
                                      </div>
                                      <button type="submit" class="btn btn-primary btn-sm mb-4">Submit</button>
                                    </form>
                                </div>
                                
                            </div> 

                           </div>
                            <div class="box mt-3">
                        
                            <div class="row">
                               
                                <div class="col-12">
                                     
                                    <div id="myCarousel" class="carousel slide" data-ride="carousel">
                                        <h6 style="color: #021058">Testimonials</h6> 
                                <!-- Carousel indicators -->
                                 
                                <!-- Wrapper for carousel items -->
                                <div class="carousel-inner">  
                                    
                                    <div class="item carousel-item active">
                                        
                                        <p class="testimonial">Aries maintains good relationships and follows up regularly about the service, to ensure that everything goes smoothly.</p>
                                        <h6>Mr.Manoj Patel</h6>
                                             <p>Relay Express</p>
                                    </div>


                                    <div class="item carousel-item">
                                        
                                        <p class="testimonial">Migration to Cloud was made so easy by CtrlS.Server was installed and set up without any problems, most importantly, zero downtime.
                                       </p>
                                       <h6>Mr.NVV Krishnam Raju</h6>
                                             <p>Seventeen Networks</p>
                                        
                                    </div>
                                        
                                                                    </div>
                                        <!-- Carousel controls -->
                                        <a class="carousel-control left carousel-control-prev" href="#myCarousel" data-slide="prev">
                                            <i class="fa fa-angle-left"></i>
                                        </a>
                                        <a class="carousel-control right carousel-control-next" href="#myCarousel" data-slide="next">
                                            <i class="fa fa-angle-right"></i>
                                        </a>
                                    </div>
                                </div>
                               
                            </div> 
                           </div> 
                        </div> 
                        </div>

                    </div>
                 </div>

            </div>

        </div>
    </div>
    <!-- #####  ##### -->
  <!-- ##### Partner Area Start ##### -->
    <div class="partner-area pt-5 pb-5">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <h6 style="color: #021058">A FEW OF OUR MORE RECOGNIZABLE CLIENTS</h6>
                    <div class="partners-logo d-flex align-items-center justify-content-between  mt-5">
                        <a href="#"><img src="img/clients-img/partner-1.png" alt=""></a>
                        <a href="#"><img src="img/clients-img/partner-2.png" alt=""></a>
                        <a href="#"><img src="img/clients-img/partner-3.png" alt=""></a>
                        <a href="#"><img src="img/clients-img/partner-4.png" alt=""></a>
                        <a href="#"><img src="img/clients-img/partner-5.png" alt=""></a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- ##### Partner Area End ##### -->
   

    <!-- ##### Footer Area Start ##### -->
   <?php include('include/footer.php'); ?>
    <!-- ##### Footer Area Start ##### -->

    <!-- ##### All Javascript Script ##### -->
    <!-- jQuery-2.2.4 js -->
    <script src="js/jquery/jquery-2.2.4.min.js"></script>
    <!-- Popper js -->
    <script src="js/bootstrap/popper.min.js"></script>
    <!-- Bootstrap js -->
    <script src="js/bootstrap/bootstrap.min.js"></script>
    <!-- All Plugins js -->
    <script src="js/plugins/plugins.js"></script>
    <!-- Active js -->
    <script src="js/active.js"></script>
</body>

</html>