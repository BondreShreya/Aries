<!DOCTYPE html>
<html lang="en">

 <?php include('include/head.php'); ?>
<style>
    td{
        text-align:center;
    }
     table, td, th {
     border: 1px dotted;
     padding:8px;
    
    }
    
    #table1 {
      border-collapse: separate;
    }

</style>
<body>
    <!-- ##### Preloader ##### -->
    <div id="preloader">
        <i class="circle-preloader"></i>
    </div>

    <!-- ##### Header Area Start ##### -->
   <?php include('include/header.php'); ?>
    <!-- ##### Header Area End ##### -->

    <!-- ##### Hero Area Start ##### -->
    <section class="hero-area">
        <div class="hero-slides owl-carousel">

            <!-- Single Hero Slide -->
            <div class="single-hero-slide1 bg-img" style="background-image: url(img/bg-img/a6.jpg);">
                <div class="container h-100">
                    <div class="row h-100 align-items-center">
                        <div class="col-12 text-center">
                             <div class="row">
                          <div class="col-12 col-md-6">
                            <h2 class="text-white pb-2 line">Hosted Dynamics,<br>
                           <span class="text-primary">Navision Sharepoint</span></h2>
                               
                          </div>
                              <div class="col-12 col-md-6"> 
                                  <p class="text-justify text-white">Aries – Hosted Microsoft Dynamics NAV is a business management solution for small and mid-sized organizations that helps you simplify and streamline your highly specialized business processes, rapidly adapting to the unique way you do business.</p>
                              </div>
                        </div>
                            <!--<div class="hero-slides-content">-->
                           
                           

                            <!--</div>-->
                        </div>
                    </div>
                        </div>
                    </div>
                    <!-- Single Hero Slide -->
        
            </div>
        </section>
        <!-- ##### Hero Area End ##### -->
    
        <section>
            <nav aria-label="breadcrumb">
              <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                <li class="breadcrumb-item active" aria-current="page"><a href="business.php">Business Solution</a></li>
                <li class="breadcrumb-item">Hosted Dynamics,
                    Navision Sharepoint</li>
              </ol>
            </nav>
        </section>
   
    <!-- ##### ##### -->
    <div class="partner-area pt-5">
        <div class="container">
                 <div class="row">
                    <div class="col-md-9">
                        <div class="row p-3" style="border-top: 2px dotted #80808059;">
                           <div class="col-12">                              
                            <h6 style="color: #021058">HOSTED DYNAMICS NAV</h6>
                                <ul>
                                    <li class="text-justify">Aries – Hosted Microsoft Dynamics NAV is a business management solution for small and mid-sized organizations that helps you simplify and streamline your highly specialized business processes, rapidly adapting to the unique way you do business.</li><br>
                                    <li class="text-justify">Aries – Hosted Microsoft Dynamics NAV provides you and your people with industry specific functionality that’s relevant to the local needs of your regions of operation, even for the most highly specialized industries and organizations.</li><br>
                                    <li class="text-justify">Through the rapid adaptability, simplified customization, and ease of use offered by hosted Microsoft Dynamics NAV, you can easily add functionality, custom applications, and online business capabilities. Microsoft Dynamics NAV enables your people be effective and your business to be competitive.</li><br>
                                </ul>
                          </div>
                          <div class="col-12">                              
                            <h6 style="color: #021058">Hosted Microsoft ERP Software Plus Service (S+S) Model:</h6>
                                <ul>
                                    <li class="text-justify">* Includes required Microsoft stack of licenses for Dynamics/CRM License</li>
                                    <li class="text-justify">* Can either SPLA (rent) or provide customer owned licenses (managed)</li>
                                    <li class="text-justify">* Unrestricted Database layer with unlimited bandwidth between Application and Database</li>
                                    <li class="text-justify">* Includes monitoring and management of the hosted environment</li>
                                    <li class="text-justify">* Automated back-up of database and application Data</li>
                                    <li class="text-justify">* Only Tier 4 Telco Facility</li>
                                    <li class="text-justify">* 99.995% Multi Homed Internet Availability</li><br>
                                    <li class="text-justify">You only pay a monthly subscription, including licensing of Navision, hosting and operation of the solution – including backup maintenance and annual updates from Microsoft.</li><br>
                                </ul>
                          </div>
                          <div class="col-12">                              
                            <h6 style="color: #021058">HOSTED DYNAMICS AX</h6>
                                <ul>
                                    <li class="text-justify">Designed for midsize and larger companies, Microsoft Dynamics AX (formerly Microsoft Axapta) is a multi-language, multi-currency enterprise resource planning (ERP) solution. With core strengths in manufacturing and e-business, there is an additional strong functionality for the wholesale and services industries.</li><br>
                                    <li class="text-justify">Hosted Microsoft Dynamics AX is an adaptable business-management solution that enables you and your people to make business decisions with confidence. Advantage – You can build on the investments in systems and software that your company might already use. Plus, the familiar working environment helps lower learning curves so users can focus less on technology and more on their business goals.</li><br>
                                    <li class="text-justify">Hosted Microsoft Dynamics AX 4.0 looks and works similar to Microsoft Outlook. This familiarity helps make it easier for your people to learn and the business systems perform at the highest efficiency. You can define links to “favorite” forms and applications for each user, and provide easy access to them from individual screens.</li><br>
                                    <li class="text-justify">Comprehensive features help automate and streamline financial, customer relationship, business services, human resources management, and supply chain processes. So by hosting Microsoft Dynamics AX, bring together people, processes, and technologies wherever they are located worldwide. Hosting Microsoft Dynamics AX helps to increase the productivity and effectiveness of your business, helping you to drive business success.</li><br>
                                </ul>
                          </div>
                          <div class="col-12">                              
                            <h6 style="color: #021058">Hosted Microsoft ERP Software Plus Service (S+S) License Model:</h6>
                                <ul>
                                    <li class="text-justify">* Includes required Microsoft stack of licenses for Dynamics/CRM License</li>
                                    <li class="text-justify">* Can either SPLA (rent) or provide customer owned licenses (managed)</li>
                                    <li class="text-justify">* Unrestricted Database layer with unlimited bandwidth between Application and Database</li>
                                    <li class="text-justify">* Includes monitoring and management of the hosted environment</li>
                                    <li class="text-justify">* Automated back-up of database and application Data:</li>
                                    <li class="text-justify">* Only Tier 4 Telco Facility</li>
                                    <li class="text-justify">* 99.995% Multi Homed Internet Availability</li>
                                    <br>
                                    <li class="text-justify">You only pay a monthly subscription, including licensing of Axapta, hosting and operation of the solution – including backup maintenance and annual updates from Microsoft.</li>
                                    <br>
                                </ul>
                          </div>
                          <div class="col-12">                              
                            <h6 style="color: #021058">MICROSOFT CRM</h6>
                                <ul>
                                    <li class="text-justify">Microsoft Dynamics CRM 4.0 is a fully integrated Customer Relationship Management (CRM) system. Microsoft Dynamics CRM gives you the capability to easily create and maintain a clear view of customers from first contact through purchase and post-sales. With tools to enhance your company’s sales, marketing, and customer service processes – along with native Microsoft Office Outlook integration – Microsoft Dynamics CRM delivers a fast, flexible, and affordable solution.</li>
                                    <br>
                                </ul>
                          </div>
                          <div class="col-12">                              
                            <h6 style="color: #021058">Advantage for Marketing: A clearer view of customers and more informed marketing investments</h6>
                                <ul>
                                    <li class="text-justify">Segment customer lists into distinct benefit groups and then market to one or more of the identified segments using a workflow-driven model. With Microsoft Dynamics CRM, your marketing professionals can leverage tools for:</li><br>
                                    <li class="text-justify">* customer segmentation</li>
                                    <li class="text-justify">* campaign planning and execution</li>
                                    <li class="text-justify">* data extraction and cleansing</li>
                                    <li class="text-justify">* analytics and reporting</li>
                                    <li class="text-justify">* marketing/sales collaboration tools</li>
                                    <li class="text-justify">* information sharing portals</li><br>
                                </ul>
                          </div>
                          <div class="col-12">                              
                            <h6 style="color: #021058">Advantage for Sales: Get more leads and close more business</h6>
                                <ul>
                                    <li class="text-justify">Access a complete view of customer data online or offline, and leverage tools that enable your sales professionals to get real-time access to leads, identify cross-sell and up-sell opportunities, and close more deals, faster. Microsoft Dynamics CRM provides:</li><br>
                                    <li class="text-justify">* lead and opportunity management</li>
                                    <li class="text-justify">* account and contact management</li>
                                    <li class="text-justify">* territory management</li>
                                    <li class="text-justify">* forecasting and sales analytics</li>
                                    <li class="text-justify">* offline and mobile device access</li>
                                    <li class="text-justify">* quick access to products, pricing, and quotes</li><br>
                                </ul>
                          </div>
                           <div class="col-12">                              
                            <h6 style="color: #021058">Customer service: Provide more value to customers</h6>
                                <ul>
                                    <li class="text-justify">Respond faster to customer service issues and empower your service organization to anticipate, address and deliver consistent, efficient customer care that contributes to long-term business profitability. Microsoft Dynamics CRM provides functionality for:</li><br>
                                    <li class="text-justify">* account and contact management</li>
                                    <li class="text-justify">* case and interaction management</li>
                                    <li class="text-justify">* product and contract management</li>
                                    <li class="text-justify">* knowledge-base management</li>
                                    <li class="text-justify">* service scheduling</li>
                                    <li class="text-justify">* workflow across teams and groups</li>
                                    <li class="text-justify">* service reporting and analytics
                                        </li><br>
                                </ul>
                          </div>
        <!--modal-->
                          
                          <div class="container box">
                              <!-- Button to Open the Modal -->
                              <div class="row p-2">
                                <div class=" col-md-8 col-lg-8 col-sm-8">
                                    <h6>Starting at Rs.50,000 per Month per user.</h6>
                                </div>
                                <div class="col-md-4 col-lg-4 col-sm-4">
                                    <button type="button" class="btn btn-info btn-sm" data-toggle="modal" data-target="#myModal">
                                         REQUEST FOR PROPOSAL
                                    </button>
                                </div>
                             </div>
                              <!-- The Modal -->
                              <div class="modal fade" id="myModal">
                                <div class="modal-dialog modal-dialog-centered">
                                  <div class="modal-content">
                                  
                                    <!-- Modal Header -->
                                    <div class="modal-header bg-info">
                                      <h4 class="modal-title">Request for a Proposal</h4>
                                      <button type="button" class="close" data-dismiss="modal">&times;</button>
                                    </div>
                                    
                                    <!-- Modal body -->
                                    <div class="box">
                                    <div class="modal-body">
                                      <div id="form-div">

                                          <div id="crmWebToEntityForm">
                                          <meta http-equiv="content-type" content="text/html;charset=UTF-8">
                                           <form action="" name="WebToLeads2569189000036872060" method="POST" onsubmit="javascript:document.charset=&quot;UTF-8&quot;; return checkMandatory2569189000036872060()" accept-charset="UTF-8">
                                        <input type="text" class="form-control" style="display:none;" name="xnQsjsdp" value="5bbf9f74877d7cbf151ef666b662b48a23ff284067d965528e240073aedb838e"> 
                                         <input type="hidden" name="zc_gad" id="zc_gad" value="undefined"> 
                                         <input type="text" style="display:none;" name="xmIwtLD" value="32ce659de9c603b6bad36dc19a4b92680016792428af0c36e0e96f992b153ff4"> 
                                         <input type="text" style="display:none;" name="actionType" value="TGVhZHM=">
                                        <input type="text" style="display:none;" name="returnURL" value="https://www.ctrls.com/thankyou.php"> 
                                        
                                        
                                        
                                              <div class="form-group row">
                                                <label class="col-sm-4 col-form-label">Name<span style="color:red;">*</span></label>
                                                <div class="col-sm-8"><input type="text" maxlength="80" name="Last Name" class="form-control textbox"></div>
                                              </div>
                                        
                                              <div class="form-group row">
                                                <label class="col-sm-4 col-form-label">Email<span style="color:red;">*</span></label>
                                                <div class="col-sm-8"><input type="text" maxlength="100" name="Email" id="email1" class="form-control textbox"></div>
                                              </div>
                                        
                                              <div class="form-group row">
                                                <label class="col-sm-4 col-form-label">Phone<span style="color:red;">*</span></label>
                                                <div class="col-sm-8"><input type="text" maxlength="30" name="Phone" id="telephone" class="form-control textbox"></div>
                                              </div>
                                        
                                              <div class="form-group row">
                                                <label class="col-sm-4 col-form-label pr-0">Company Name</label>
                                                <div class="col-sm-8">
                                                  <textarea name="Description" rows="3" maxlength="32000" class="form-control textbox">&nbsp;</textarea>
                                                </div>
                                              </div>
                                        
                                              <div style="display:none;">
                                                <label class="col-sm-4 col-form-label">Page URL</label>
                                                <div class="col-sm-8">
                                                  <textarea name="LEADCF2" maxlength="2000" id="pageLocation">www.ctrls.com&nbsp;</textarea>
                                                </div>
                                              </div>
                                        
                                              <div style="display:none;">
                                                <label class="col-sm-4 col-form-label">Lead Source</label>
                                                <div class="col-sm-8">
                                                  <select style="width:250px;" name="Lead Source">
                                                    <option value="-None-">-None-</option>
                                                    <option value="Cloud4C Google Ads">Cloud4C Google Ads</option>
                                                    <option value="Cloud4C.com">Cloud4C.com</option>
                                                    <option value="Cloud4C.com Google Adwords">Cloud4C.com Google Adwords</option>
                                                    <option value="Cloud4c.com LivServ">Cloud4c.com LivServ</option>
                                                    <option value="Cloud4C.com SalesIQ Chat">Cloud4C.com SalesIQ Chat</option>
                                                    <option value="Cloud4C.com Website">Cloud4C.com Website</option>
                                                    <option value="Colocation-ctrlS.com">Colocation-ctrlS.com</option>
                                                    <option value="Colocation-ctrlS.com - Chat">Colocation-ctrlS.com - Chat</option>
                                                    <option value="CtrlS Google Ads">CtrlS Google Ads</option>
                                                    <option value="CtrlS.com">CtrlS.com</option>
                                                    <option value="CtrlS.com - Data Center">CtrlS.com - Data Center</option>
                                                    <option value="CtrlS.com - Data Center - Chat">CtrlS.com - Data Center - Chat</option>
                                                    <option value="CtrlS.com Google Adwords">CtrlS.com Google Adwords</option>
                                                    <option value="CtrlS.com SalesIQ Chat">CtrlS.com SalesIQ Chat</option>
                                                    <option selected="" value="CtrlS.com Website">CtrlS.com Website</option>
                                                    <option value="Ctrls.in Chat">Ctrls.in Chat</option>
                                                    <option value="CtrlS.in SalesIQ Chat">CtrlS.in SalesIQ Chat</option>
                                                    <option value="CtrlS.in Website">CtrlS.in Website</option>
                                                    <option value="Downloads Cloud4C">Downloads Cloud4C</option>
                                                    <option value="Downloads CtrlS">Downloads CtrlS</option>
                                                    <option value="Email Marketing">Email Marketing</option>
                                                    <option value="Form Fills Cloud4C">Form Fills Cloud4C</option>
                                                    <option value="Form Fills CtrlS">Form Fills CtrlS</option>
                                                    <option value="Human Resource">Human Resource</option>
                                                    <option value="Linkedin">Linkedin</option>
                                                    <option value="Managed services - Facebook">Managed services - Facebook</option>
                                                    <option value="Managed services - Google">Managed services - Google</option>
                                                    <option value="Marketing Cloud4C">Marketing Cloud4C</option>
                                                    <option value="Marketing CtrlS">Marketing CtrlS</option>
                                                    <option value="Publishers">Publishers</option>
                                                    <option value="Referrals">Referrals</option>
                                                    <option value="Registration">Registration</option>
                                                    <option value="Toll Free Cloud4C">Toll Free Cloud4C</option>
                                                    <option value="Toll Free CtrlS">Toll Free CtrlS</option>
                                                  </select>
                                                </div>
                                              </div>
                                        
                                              <div style="display:none;">
                                                <label class="col-sm-4 col-form-label">Paid Identifier</label>
                                                <div class="col-sm-8">
                                                <select style="width:250px;" name="LEADCF14">
                                                  <option value="-None-">-None-</option>
                                                  <option value="Paid">Paid</option>
                                                  <option selected="" value="Non Paid">Non Paid</option>
                                                </select>
                                                </div>
                                              </div>
                                        
                                              <div class="form-group row">
                                                <label class="col-sm-4 col-form-label">Enter the Captcha</label>
                                                <div class="col-sm-8">
                                                  <input type="text" maxlength="80" name="enterdigest" id="captcha" class="form-control">
                                                  <div class="mt-2 mb-3">
                                                    <img id="imgid" src="https://crm.zoho.com/crm/CaptchaServlet?formId=32ce659de9c603b6bad36dc19a4b92680016792428af0c36e0e96f992b153ff4&amp;grpid=5bbf9f74877d7cbf151ef666b662b48a23ff284067d965528e240073aedb838e"> 
                                                    <a href="javascript:;" onclick="reloadImg()" class="text-success">Reload</a>
                                                  </div>
                                                  <input id="formsubmit" type="submit" value="Submit" class="btn btn-submit btn-success">
                                                </div>
                                              </div>
                                              
                                              <script>
                                                var mndFileds=new Array('Last Name','Email','Phone');
                                                var fldLangVal=new Array('Name','Email','Phone'); 
                                                var name='';
                                                var email='';
                                                
                                                /* Do not remove this code. */
                                                function reloadImg() {
                                                  if(document.getElementById('imgid').src.indexOf('&d') !== -1 ) {
                                                    document.getElementById('imgid').src=document.getElementById('imgid').src.substring(0,document.getElementById('imgid').src.indexOf('&d'))+'&d'+new Date().getTime();
                                                  }  else {
                                                    document.getElementById('imgid').src = document.getElementById('imgid').src+'&d'+new Date().getTime();
                                                  } 
                                                }
                                        
                                                function checkMandatory2569189000036872060() {
                                                  for(i=0;i<mndFileds.length;i++) {
                                                    var fieldObj=document.forms['WebToLeads2569189000036872060'][mndFileds[i]];
                                                    if(fieldObj) {
                                                      if (((fieldObj.value).replace(/^\s+|\s+$/g, '')).length==0) {
                                                      if(fieldObj.type =='file'){
                                                                  alert('Please select a file to upload.');
                                                                  fieldObj.focus();
                                                                  return false;
                                                              }
                                                              $(fieldObj).addClass('error');
                                                              fieldObj.focus();
                                                              setTimeout(function(){ 
                                                                  alert(fldLangVal[i] +' cannot be empty.');
                                                              }, 500);
                                                              return false;
                                                          }  else if(fieldObj.nodeName=='SELECT') {
                                                              if(fieldObj.options[fieldObj.selectedIndex].value=='-None-') {
                                                                  alert(fldLangVal[i] +' cannot be none.');
                                                                  fieldObj.focus();
                                                                  return false;
                                                              }
                                                          } else if(fieldObj.type =='checkbox'){
                                                              if(fieldObj.checked == false){
                                                                  alert('Please accept  '+fldLangVal[i]);
                                                                  fieldObj.focus();
                                                                  return false;
                                                              }
                                                          } else if (fieldObj.name === "Phone") {
                                                              if (!isPhone(fieldObj.value)) {
                                                                  $("#telephone").focus();
                                                                  alert("Please enter valid Phone Number");
                                                                  return false;
                                                              }
                                                          } else if (fieldObj.name === "Email") {
                                                              if (!isEmail(fieldObj.value)) {
                                                                  $("#email1").focus();
                                                                  alert("Please enter valid email address");
                                                                  return false;
                                                              }
                                                          }
                                                          try {
                                                              if(fieldObj.name == 'Last Name') {
                                                                  name = fieldObj.value;
                                                              }
                                                          } catch (e) {
                                              
                                                          }
                                                      }
                                                  }
                                                  if($('#captcha').val() == "") {
                                                      alert("Please enter below code");
                                                      return false;
                                                  } else {
                                                      //alert("Thank you");
                                                  }
                                                  
                                                  setTimeout(function(){
                                                    window.parent.fancyboxCloser();
                                                  }, 100);
                                                  document.getElementById('formsubmit').disabled=true;
                                                  }
                                                </script>
                                              </form>
                                          <!-- Do not remove this code. -->
                                             <iframe name="captchaFrame" style="display:none;" __idm_frm__="516"></iframe>
                                        </div>
                                        </div>
                                    </div>
                                    
                                    <!-- Modal footer -->
                                    <!--<div class="modal-footer">-->
                                    <!--  <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>-->
                                    <!--</div>-->
                                    
                                  </div>
                                </div>
                              </div>
                              </div>
  
                          </div>
                          
            <!--//modal-->
                        </div>
                    </div>
                    
                    <div class="col-md-3">
                        <div class="box">
                        <div class="row">
                            <h6 style="color: #021058">Need help deciding?</h6>
                            <p>CONTACT US</p>
                        </div>
                            <div class="row">
                               
                                <div class="col-3">
                                    <i class="fa fa-headphones" aria-hidden="true"></i>
                                </div>
                                <div class="col-9"> 
                                        <p><b style="color: #021058">1800-102-8757</b></p>
                                        <p>Sales Toll Free Number</p>
                                </div>
                            </div> 
                           </div>
                            
                           <!-- <div class="box mt-3">-->
                           <!--     <div id="crmWebToEntityForm" class="form-box">-->
                           <!--        <meta http-equiv="content-type" content="text/html;charset=UTF-8">-->
                           <!--     	<form action="" name="WebToLeads2569189000036821042" method="POST" onsubmit="javascript:document.charset=&quot;UTF-8&quot;; return checkMandatory2569189000036821042()" accept-charset="UTF-8" siq_id="autopick_4437">-->
                           <!--     		<input type="text" style="display:none;" name="xnQsjsdp" value="5bbf9f74877d7cbf151ef666b662b48a23ff284067d965528e240073aedb838e"> -->
                           <!--      <input type="hidden" name="zc_gad" id="zc_gad" value=""> -->
                           <!--      <input type="text" style="display:none;" name="xmIwtLD" value="32ce659de9c603b6bad36dc19a4b9268a1e34860f3aae765e5c067e4d81d605e"> -->
                           <!--      <input type="text" style="display:none;" name="actionType" value="TGVhZHM=">-->
                           <!--     <input type="text" style="display:none;" name="returnURL" value="https://www.ctrls.com/thankyou.php"> -->
                                				
                           <!--     		<h6 style="color: #021058">Sounds good?<span>Fill up the form below &amp; Get Attractive Offers</span></h6>-->
                           <!--     		<ul>-->
                           <!--     			<li>-->
                           <!--     				<label>Name<span style="color:red;">*</span></label>-->
                           <!--     				<input type="text" class="form-control" maxlength="80" name="Last Name">-->
                           <!--     			</li>-->
                           <!--     			<li>-->
                           <!--     				<label>Your email address<span style="color:red;">*</span></label>-->
                           <!--     				<input type="text" class="form-control" id="email" maxlength="100" name="Email">-->
                           <!--     			</li>-->
                           <!--     			<li>-->
                           <!--     				<label>Phone number<span style="color:red;">*</span></label>-->
                           <!--     				<input type="text" class="form-control" id="phone" maxlength="30" name="Phone">-->
                           <!--     			</li>-->
                                
                           <!--     			<li>-->
                           <!--     				<label>Comments</label>-->
                           <!--     				<textarea class="form-control" id="msg" name="Description" maxlength="32000" rows="3" style="height: 50px !important;">&nbsp;</textarea>-->
                           <!--     			</li><br>-->
                                			
                           <!--     			<li>-->
                           <!--     				<img id="imgid" src="https://crm.zoho.com/crm/CaptchaServlet?formId=32ce659de9c603b6bad36dc19a4b9268a1e34860f3aae765e5c067e4d81d605e&amp;grpid=5bbf9f74877d7cbf151ef666b662b48a23ff284067d965528e240073aedb838e"><br>-->
                                
                           <!--     				<label>Enter the code above here :</label><br>-->
                                
                           <!--     				<input type="text" class="form-control" maxlength="80" name="enterdigest"><br>-->
                           <!--     				<small>Can't read the image? click <a href="javascript:;" onclick="reloadImg()">here</a> to refresh</small>-->
                                				
                           <!--     			</li>-->
                           <!--     			<li style="display:none;">-->
                           <!--     				<label>Lead Source</label>-->
                           <!--     				<select name="Lead Source">-->
                           <!--     					<option value="-None-">-None-</option>-->
                           <!--     					<option value="Cloud4C Google Ads">Cloud4C Google Ads</option>-->
                           <!--     					<option value="CtrlS.com">CtrlS.com</option>-->
                           <!--     					<option value="Cloud4C.com Google Adwords">Cloud4C.com Google Adwords</option>-->
                           <!--     					<option value="Cloud4c.com LivServ">Cloud4c.com LivServ</option>-->
                           <!--     					<option value="Cloud4C.com SalesIQ Chat">Cloud4C.com SalesIQ Chat</option>-->
                           <!--     					<option value="Cloud4C.com Website">Cloud4C.com Website</option>-->
                           <!--     					<option value="Colocation-ctrlS.com">Colocation-ctrlS.com</option>-->
                           <!--     					<option value="Colocation-ctrlS.com - Chat">Colocation-ctrlS.com - Chat</option>-->
                           <!--     					<option value="CtrlS Google Ads">CtrlS Google Ads</option>-->
                           <!--     					<option value="CtrlS.com - Data Center">CtrlS.com - Data Center</option>-->
                           <!--     					<option value="CtrlS.com - Data Center - Chat">CtrlS.com - Data Center - Chat</option>-->
                           <!--     					<option value="CtrlS.com Google Adwords">CtrlS.com Google Adwords</option>-->
                           <!--     					<option value="CtrlS.com SalesIQ Chat">CtrlS.com SalesIQ Chat</option>-->
                           <!--     					<option selected="" value="CtrlS.com Website">CtrlS.com Website</option>-->
                           <!--     					<option value="Ctrls.in Chat">Ctrls.in Chat</option>-->
                           <!--     					<option value="CtrlS.in SalesIQ Chat">CtrlS.in SalesIQ Chat</option>-->
                           <!--     					<option value="CtrlS.in Website">CtrlS.in Website</option>-->
                           <!--     					<option value="Downloads Cloud4C">Downloads Cloud4C</option>-->
                           <!--     					<option value="Downloads CtrlS">Downloads CtrlS</option>-->
                           <!--     					<option value="Email Marketing">Email Marketing</option>-->
                           <!--     					<option value="Form Fills Cloud4C">Form Fills Cloud4C</option>-->
                           <!--     					<option value="Form Fills CtrlS">Form Fills CtrlS</option>-->
                           <!--     					<option value="Human Resource">Human Resource</option>-->
                           <!--     					<option value="Linkedin">Linkedin</option>-->
                           <!--     					<option value="Managed services - Facebook">Managed services - Facebook</option>-->
                           <!--     					<option value="Managed services - Google">Managed services - Google</option>-->
                           <!--     					<option value="Marketing Cloud4C">Marketing Cloud4C</option>-->
                           <!--     					<option value="Marketing CtrlS">Marketing CtrlS</option>-->
                           <!--     					<option value="Publishers">Publishers</option>-->
                           <!--     					<option value="Referrals">Referrals</option>-->
                           <!--     					<option value="Registration">Registration</option>-->
                           <!--     					<option value="Toll Free Cloud4C">Toll Free Cloud4C</option>-->
                           <!--     					<option value="Toll Free CtrlS">Toll Free CtrlS</option>-->
                           <!--     				</select>-->
                           <!--     			</li>-->
                           <!--     			<li style="display:none;">-->
                           <!--     				<label>Page URL</label>-->
                           <!--     				<textarea id="pageUrl" name="LEADCF2" maxlength="2000"></textarea>-->
                           <!--     			</li>-->
                           <!--     			<li style="display:none;">-->
                           <!--     				<label>Paid Identifier</label>-->
                           <!--     				<select name="LEADCF14">-->
                           <!--     					<option value="-None-">-None-</option>-->
                           <!--     					<option value="Paid">Paid</option>-->
                           <!--     					<option selected="" value="Non Paid">Non Paid</option>-->
                           <!--     				</select>-->
                           <!--     			</li>-->
                           <!--     			<li>-->
                           <!--     				<input class="btn btn-success btn-block" style="color:#FFF; background:#090; font-size:15px;" id="formsubmit" type="submit" value="Submit">-->
                           <!--     			</li><br>-->
                           <!--     		</ul>-->
                                		
                           <!--     		<script>-->
                           <!--     			var newUrl = window.location.href;-->
                           <!--     			console.log('Page Url:', newUrl);-->
                                
                           <!--     			$(document).ready(function(){-->
                           <!--     				$('#pageUrl').val(newUrl);-->
                           <!--     			})-->
                                			
                           <!--     			function isEmail(email) {-->
                           <!--     				var pattern = new RegExp(/^((([a-z]|\d|[!#\$%&'\*\+\-\/=\?\^_`{\|}~]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])+(\.([a-z]|\d|[!#\$%&'\*\+\-\/=\?\^_`{\|}~]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])+)*)|((\x22)((((\x20|\x09)*(\x0d\x0a))?(\x20|\x09)+)?(([\x01-\x08\x0b\x0c\x0e-\x1f\x7f]|\x21|[\x23-\x5b]|[\x5d-\x7e]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(\\([\x01-\x09\x0b\x0c\x0d-\x7f]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]))))*(((\x20|\x09)*(\x0d\x0a))?(\x20|\x09)+)?(\x22)))@((([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.)+(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.?$/i);-->
                           <!--     				if (pattern.test(email)) {-->
                           <!--     					return true;-->
                           <!--     				}-->
                           <!--     				return false;-->
                           <!--     			}-->
                                
                           <!--     			var mndFileds=new Array('Last Name','Email','Phone', 'enterdigest');-->
                           <!--     			var fldLangVal=new Array('Name','Email address','Phone number', 'Captcha');-->
                           <!--     			var name='';-->
                           <!--     			var email='';-->
                                			
                                			<!--/* Do not remove this code. */-->
                           <!--     			function reloadImg() {-->
                           <!--     				if(document.getElementById('imgid').src.indexOf('&d') !== -1 ) {-->
                           <!--     					document.getElementById('imgid').src=document.getElementById('imgid').src.substring(0,document.getElementById('imgid').src.indexOf('&d'))+'&d'+new Date().getTime();-->
                           <!--     				}  else {-->
                           <!--     					document.getElementById('imgid').src = document.getElementById('imgid').src+'&d'+new Date().getTime();-->
                           <!--     				} -->
                           <!--     			}-->
                           <!--     			function isPhone(phone) {-->
                           <!--     				if (!$.isNumeric(phone)) {-->
                           <!--     					return false;-->
                           <!--     				}-->
                           <!--     				if (phone.length < 10 || phone.length > 15) {-->
                           <!--     					return false;-->
                           <!--     				}-->
                           <!--     				return true;-->
                           <!--     			}-->
                                
                           <!--     			function checkMandatory2569189000036821042() {-->
                           <!--     				for(i=0;i<mndFileds.length;i++) {-->
                           <!--     					var fieldObj=document.forms['WebToLeads2569189000036821042'][mndFileds[i]];-->
                           <!--     					if(fieldObj) {-->
                           <!--     						if (((fieldObj.value).replace(/^\s+|\s+$/g, '')).length==0) {-->
                           <!--     							if(fieldObj.type =='file') { -->
                           <!--     								alert('Please select a file to upload.');-->
                           <!--     								fieldObj.focus();-->
                           <!--     								return false;-->
                           <!--     							}-->
                                							
                           <!--     							alert(fldLangVal[i] +' cannot be empty.');-->
                           <!--     							fieldObj.focus();-->
                           <!--     							return false;-->
                           <!--     						}  else if(fieldObj.nodeName=='SELECT') {-->
                           <!--     							if(fieldObj.options[fieldObj.selectedIndex].value=='-None-') {-->
                           <!--     								alert(fldLangVal[i] +' cannot be none.');-->
                           <!--     								fieldObj.focus();-->
                           <!--     								return false;-->
                           <!--     							}-->
                           <!--     						} else if(fieldObj.type =='checkbox'){-->
                           <!--     							if(fieldObj.checked == false){-->
                           <!--     								alert('Please accept  '+fldLangVal[i]);-->
                           <!--     								fieldObj.focus();-->
                           <!--     								return false;-->
                           <!--     							}-->
                           <!--     						} else if (fieldObj.name === "Email") {-->
                           <!--     							if (!isEmail(fieldObj.value)) {-->
                           <!--     								$("#email").focus();-->
                           <!--     								alert("Please enter valid email address");-->
                           <!--     								return false;-->
                           <!--     							}-->
                           <!--     						} else if (fieldObj.name === "Phone") {-->
                           <!--     							if (!isPhone(fieldObj.value)) {-->
                           <!--     								alert("Please enter a valid Phone Number");-->
                           <!--     								$("#phone").focus();-->
                           <!--     								return false;-->
                           <!--     							}-->
                           <!--     						} try {-->
                           <!--     							if(fieldObj.name == 'Last Name') {-->
                           <!--     								name = fieldObj.value;-->
                           <!--     							}-->
                           <!--     						} catch (e) {-->
                                
                           <!--     						}-->
                           <!--     					}-->
                           <!--     				}-->
                           <!--     				document.getElementById('formsubmit').disabled=true;-->
                           <!--     			}-->
                                			
                           <!--     		</script>-->
                           <!--     	</form>-->
                                	
                                	<!-- Do not remove this code. -->
                           <!--     	<iframe name="captchaFrame" style="display:none;" __idm_frm__="70"></iframe>-->
                           <!--     </div>-->
                           <!--</div>-->
                            <div class="box mt-3">
                        <div class="row">
                            <h6 style="color: #021058">Sounds good?</h6>
                            <p>FILL UP THE FORM BELOW & GET ATTRACTIVE OFFERS</p>
                        </div>
                            <div class="row">
                               
                                <div class="col-12">
                                    <form action="/action_page.php">
                                         <div class="form-group">
                                        <label for="name">Name</label>
                                        <input type="name" class="form-control" id="name">
                                      </div>
                                      <div class="form-group">
                                        <label for="email"> Your Email address</label>
                                        <input type="email" class="form-control" id="email">
                                      </div>
                                      <div class="form-group">
                                        <label for="pwd">Phone Number</label>
                                        <input type="password" class="form-control" id="pwd">
                                      </div>
                                       <div class="form-group">
                                        <label for="pwd">Comments</label>
                                        <textarea type="password" class="form-control" id="pwd"></textarea>
                                      </div>
                                      <button type="submit" class="btn btn-primary btn-sm mb-4">Submit</button>
                                    </form>
                                </div>
                                
                            </div> 

                           </div>
                            
                            <div class="box mt-3">
                        
                            <div class="row">
                               
                                <div class="col-12">
                                     
                                    <div id="myCarousel" class="carousel slide" data-ride="carousel">
                                        <h6 style="color: #021058">Testimonials</h6> 
                                <!-- Carousel indicators -->
                                 
                                <!-- Wrapper for carousel items -->
                                <div class="carousel-inner">  
                                    
                                    <div class="item carousel-item active">
                                        
                                        <p class="testimonial">Aries maintains good relationships and follows up regularly about the service, to ensure that everything goes smoothly.</p>
                                        <h6>Mr.Manoj Patel</h6>
                                             <p>Relay Express</p>
                                    </div>


                                    <div class="item carousel-item">
                                        
                                        <p class="testimonial">Migration to Cloud was made so easy by CtrlS.Server was installed and set up without any problems, most importantly, zero downtime.
                                       </p>
                                       <h6>Mr.NVV Krishnam Raju</h6>
                                             <p>Seventeen Networks</p>
                                        
                                    </div>
                                        
                                                                    </div>
                                        <!-- Carousel controls -->
                                        <a class="carousel-control left carousel-control-prev" href="#myCarousel" data-slide="prev">
                                            <i class="fa fa-angle-left"></i>
                                        </a>
                                        <a class="carousel-control right carousel-control-next" href="#myCarousel" data-slide="next">
                                            <i class="fa fa-angle-right"></i>
                                        </a>
                                    </div>
                                </div>
                               
                            </div> 
                           </div> 
                        </div> 
                        </div>

                    </div>
                 </div>

            </div>

        </div>
    </div>
    <!-- #####  ##### -->
  <!-- ##### Partner Area Start ##### -->
    <div class="partner-area pt-5 pb-5">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <h6 style="color: #021058">A FEW OF OUR MORE RECOGNIZABLE CLIENTS</h6>
                    <div class="partners-logo d-flex align-items-center justify-content-between  mt-5">
                        <a href="#"><img src="img/clients-img/partner-1.png" alt=""></a>
                        <a href="#"><img src="img/clients-img/partner-2.png" alt=""></a>
                        <a href="#"><img src="img/clients-img/partner-3.png" alt=""></a>
                        <a href="#"><img src="img/clients-img/partner-4.png" alt=""></a>
                        <a href="#"><img src="img/clients-img/partner-5.png" alt=""></a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- ##### Partner Area End ##### -->
   

    <!-- ##### Footer Area Start ##### -->
   <?php include('include/footer.php'); ?>
    <!-- ##### Footer Area Start ##### -->

    <!-- ##### All Javascript Script ##### -->
    <!-- jQuery-2.2.4 js -->
    <script src="js/jquery/jquery-2.2.4.min.js"></script>
    <!-- Popper js -->
    <script src="js/bootstrap/popper.min.js"></script>
    <!-- Bootstrap js -->
    <script src="js/bootstrap/bootstrap.min.js"></script>
    <!-- All Plugins js -->
    <script src="js/plugins/plugins.js"></script>
    <!-- Active js -->
    <script src="js/active.js"></script>
</body>

</html>